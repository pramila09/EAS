<?php
session_start();
include('includes/config.php');
if(isset($_POST['signin']))
{
	$uname = $_POST['username'];
	$pass = $_POST['password'];
	$sql = "SELECT username, password FROM admin WHERE username = :uname and password = :pass";
	$query = $dbh -> prepare($sql);
	$query->bindParam(':uname', $uname, PDO::PARAM_STR);
	$query->bindParam(':pass', $pass, PDO::PARAM_STR);
	$query->execute();
	$result = $query -> fetchAll(PDO::FETCH_OBJ);
	
	if($query-> rowCount() > 0)
	{
		$_SESSION['alogin'] = $_POST['username'];
		echo "<script type = 'text/javascript'> document.location = 'dashboard.php'; </script>";
	}
	else
	{
		echo "<script>alert('invalid details!'); </script>";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin | Login</title>
	<link rel="stylesheet" type="text/css" href="css/loginstyle.css">
	<link rel="stylesheet" href="fontawesome/css/all.css">
</head>
<body>
	<div class="header-style">
		<span>Admin Login</span>
	</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="signin" method="post">
  				<input type="text" name="username" id="username" placeholder="username" autocomplete="off" required>
  				<input type="password" name="password" id="password" placeholder="password" autocomplete="off" required>
  				<input class="button button2" type="submit" name="signin" value="Login">
  			</form>
  		</div>
	</div>

</body>
</html>