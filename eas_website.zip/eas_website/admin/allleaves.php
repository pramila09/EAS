<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
if(isset($_POST['update']))
{ 
$status=$_POST['status'];   
$sql="update tblleaves set Status=:status";
$query = $dbh->prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':did',$did,PDO::PARAM_STR);
$query->execute();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php')?>

	<div class="datatable-header-style">All Leave History</div>

	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="post"><?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
  					<table id="example" class="display" style="width:100%">
        				<thead>
            				<tr>
				                <th>Sr no</th>
				                <th>EmpName</th>
                                <th>Email</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Description</th>
                                <th>Admin Remark</th>
                               
            				    </tr>
        				</thead>
                <tbody>
                    <?php $sql = "SELECT tbleaves.id,tblemployees.EmpId,tblemployees.Fname,tblemployees.emailid, tbleaves.empid, tbleaves.fromdate, tbleaves.todate,tbleaves.Status, tbleaves.leavetype, tbleaves.description from tbleaves join tblemployees on tbleaves.empid = tblemployees.EmpId";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>
                    <tr>
                                            <td> <?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($result->Fname);?></td>
                                            <td><?php echo htmlentities($result->emailid)?></td>
                                            <td><?php echo htmlentities($result->fromdate);?></td>
                                            <td> <?php echo htmlentities($result->todate);?></td>
                                            <td> <?php echo htmlentities($result->leavetype);?></td>
                                            <td><?php $stats=$result->Status;
                                                if($stats==1){?>
                                                <span style="color: green">Approved</span>
                                                 <?php } if($stats==2)  { ?>
                                                <span style="color: red">Not Approved</span>
                                                <?php } if($stats==0)  { ?>
                                                 <span style="color: blue">waiting for approval</span>
                                                 <?php } ?></td>
                                            <td><?php echo htmlentities($result->description);?></td>
                                            <td><a href="adminremark.php?levid=<?php echo htmlentities($result->id);?>">Take Action</a></td>
                                           
                                            
                                        </tr>
                                           
                                        </tr>
                                    <?php $cnt++;} }?>
                  </tbody>
        			</table>
  			</form>
  		</div>
	</div>
    <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>

</body>
</html>
<?php } ?>