<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql = "delete from  holiday  WHERE id=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();
$msg="Holiday record deleted!";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
  <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php');?>
	<div class="datatable-header-style">Holiday Details..</div>
  <a class="col-3" href="addholiday.php"><span class="new-holiday">New Holiday</span></a>

	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="post"><?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
  					<table id="example" class="display" style="width:100%">
        				<thead>
            				<tr>
				                <th>Sr no</th>
                                <th>Type</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Registed At</th>
                                <th>Action</th>
            				    </tr>
        				</thead>
                <tbody>
                    <?php $sql = "SELECT Type, StartDate, EndDate, regDate, id from holiday";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>
                    <tr>
                                            <td> <?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($result->Type);?></td>
                                            <td><?php echo htmlentities($result->StartDate);?></td>
                                            <td> <?php echo htmlentities($result->EndDate);?></td>
                                            <td><?php echo htmlentities($result->regDate);?></td>
                                            <td><a href="editholiday.php?holid=<?php echo htmlentities($result->id);?>"><i class="fas fa-edit"></i></a>
                                            	<a href="holiday.php?del=<?php echo htmlentities($result->id);?>" onclick="return confirm('Do you want to delete?');"><i class="fas fa-trash"></i></a></td>
                                        </tr>
                                           
                                        </tr>
                                    <?php $cnt++;} }?>
                  </tbody>
        			</table>
  			</form>
  		</div>
	</div>
    <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>
</body>
</html>
<?php } ?>