<?php
session_start();
if(!isset($_SESSION["username"]))
  die("not logged in");
$username=$_SESSION["username"];
$empid=$_SESSION["empid"];


     include 'config.inc.php';
// Code for change password 
if(isset($_POST['password']))
    {
      $final='';
$password=$_POST['password'];
$newpassword=$_POST['newpassword'];
$username=$_SESSION['username'];
//echo $username;

$empid=$_SESSION["empid"];
//echo $empid;
    $sql ="SELECT password FROM tblemployees WHERE password=:password and Empid=$empid";
   // echo $sql;
$query= $conn -> prepare($sql);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
                foreach($results as $result)
                {
                  
                                            $pass = htmlentities($result->password);
                                           $con="update tblemployees set password=:newpassword where Empid=$empid and password=:pass";
//echo $con;
$chngpwd = $conn->prepare($con);
$chngpwd-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
$chngpwd-> bindParam(':pass', $pass, PDO::PARAM_STR);
$chngpwd->execute();
 $final="true";

}
 }


else {
$error="Your current password is wrong!";   
$final="false"; 
}
     echo $final;                                        
     }                            







?>




