
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php')?>

	<div class="datatable-header-style">Attendance</div>
    <a class="col-3" href="viewAttendance.php"><span class="dept-details">Attendance Report</span></a>

	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="post">
  					<table id="example" class="display" style="width:100%">
        				<thead>
            				<tr>
				                
                                <th>Sr No</th>
                                <th>EmpId</th>
                                <th>EmpName</th>
                                <th>EnrollTime</th>
                                <th>EnrollDate</th>
                               
            				</tr>
        				</thead>
        					<tbody>
                                <?php
try{
      include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
}

if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }

//Now you can use this query to see how many rows you are dealing with
//Edit $result as your query
 $result = "SELECT AttendanceLogId FROM tblAttendanceLog";
//$rows = mssql_num_rows($result);
$getResults=$conn->prepare($result);
$getResults->execute();
ini_set('memory_limit','-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
//$row=1;
$rows=$getResults-> rowCount();?>



//This is the number of results displayed per page 
<?php $page_rows = 10; 

//This tells us the page number of our last page 
$last = ceil($rows/$page_rows); 

//Seeing if the current page we are on is the last
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; }

//This sets the range to display in our query 
$max = ($pagenum - 1) * $page_rows;

 $tsql="SELECT top $page_rows tblEmployee.EmployeeId,tblEmployee.EmpName,tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime FROM tblAttendanceLog,tblEmployee WHERE tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo and tblAttendanceLog.AttendanceLogId not in(select top $max AttendanceLogId from tblAttendanceLog order by AttendanceLogId desc)ORDER BY AttendanceLogId desc";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt = 1;
foreach($results as $row){?>
    <tr><td><?php echo ($cnt);?></td><td><?php echo $row['EmployeeId'];?></td><td><?php echo $row['EmpName'];?></td>
        <td><?php echo $row['EnrollTime'];?></td><td><?php echo $row['EnrollDate'];?></td>
    </tr>
    
<?php $cnt++; } ?>


        					</tbody>
        			</table>
  			</form>
<?php
echo "<p>";

// This shows the page they are on, and the total number of pages
echo " --Page $pagenum of $last-- <p>";

// First we check if we are on page one. If we are then we don't need a link to the previous page or the first page so we do nothing. If we aren't then we generate links to the 

//first page, and to the previous page.
if ($pagenum == 1) { } 
else 
{
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=1'> <<-First</a> ";
echo " ";
$previous = $pagenum-1;
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$previous'> <-Previous</a> ";
} 

//just a spacer
echo " ---- ";

//This does the same as above, only checking if we are on the last page, and then generating the Next and Last links
if ($pagenum == $last) 
{
} 
else {
$next = $pagenum+1;
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$next'>Next -></a> ";
echo " ";
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$last'>Last ->></a> ";
} ?>
</body>


<script type="text/javascript">
		$(document).ready(function() {
    $('#example').DataTable(
{ language: {
        searchPlaceholder: "Search records",
        search: "",
      }
    })

} );
	</script>

</html>
