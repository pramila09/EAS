<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
// Code for change password 
if(isset($_POST['change']))
    {
$password=md5($_POST['password']);
$newpassword=md5($_POST['newpassword']);
$username=$_SESSION['alogin'];
    $sql ="SELECT password FROM admin WHERE password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
$con="update admin set password=:newpassword";
$chngpwd = $dbh->prepare($con);
$chngpwd-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
$chngpwd->execute();
$msg="Your Password succesfully changed!";
}
else {
$error="Your current password is wrong!";    
}
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
</head>
<body>
	<?php include('includes/header.php')?>
	<div class="header-style">Change Password</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="chngpwd" method="post">
  				<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

  				<input type="password" name="password" id="password" placeholder="current password" autocomplete="off" required>
  				<input type="password" name="newpassword" id="newpassword" placeholder="new password" autocomplete="off" required>
  				<input type="password" name="confirmpassword" id="confirmpassword" placeholder="confirm password" autocomplete="off" required>
  				<input class="button button2" type="submit" name="change" value="Change Password" onclick="return valid();">
  			</form>
  		</div>
	</div>

</body>
</html>
<?php } ?> 