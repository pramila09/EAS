<?php
session_start();
if(!isset($_SESSION["username"]))
	die("not logged in");
$username=$_SESSION["username"];
$empid=$_SESSION["empid"];

include 'config.inc.php';
//echo $empid;



    //initial query
    $query = "Select * FROM tblemployees where Empid = :Empid";

    $query_params = array(':Empid' => $empid);

    //execute query
    try {
        $stmt = $conn -> prepare($query);
        $result = $stmt -> execute($query_params);
    } catch (PDOException $ex) {
        $response["success"] = 0;
        $response["message"] = "Database Error!";
        die(json_encode($response));
    }

    // Finally, we can retrieve all of the found rows into an array using fetchAll 
    $rows = $stmt -> fetchAll();

    if ($rows) {
        $response["success"] = 1;
        $response["message"] = "Post Available!";
        $response["Empid"] = array();

        foreach($rows as $row) {
            $Empid = array();
            $Empid["Fname"] = $row["Fname"];
            $Empid["emailid"] = $row["emailid"];
            $Empid["department"] = $row["department"];
            $Empid["District"] = $row["District"];
			$Empid["regdate"] = $row["regdate"];
            $Empid["RemainingDays"] = $row["RemainingDays"];

            //update our repsonse JSON data
            array_push($response["Empid"], $Empid);
        }

        // echoing JSON response
        echo json_encode($response);

    } else {
        $response["success"] = 0;
        $response["message"] = "No user available!";
        die(json_encode($response));
    }



       ?>