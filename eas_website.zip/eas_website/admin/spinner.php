<?php
$host="localhost";
$username="root";
$password="";
$db="employees";
$con=mysqli_connect($host,$username,$password,$db) or die("connection failed");
mysqli_select_db($con,$db) or die("db selection failed");
$result = mysqli_query($con,"SELECT leavetype from tbleavestypes");
while($row = mysqli_fetch_assoc($result)){
	$tmp[]=$row;
}
echo json_encode($tmp);
mysqli_close($con);
?>