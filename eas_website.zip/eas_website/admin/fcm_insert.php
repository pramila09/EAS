<?php

session_start();

if(!isset($_SESSION["username"]))
	die("not logged in");
$username=$_SESSION["username"];
$empid=$_SESSION["empid"];

echo $empid;

require "init.php";

if(isset($_POST['fcm_token']))
{

 $fcm_token=$_POST['fcm_token'];
 //$sql= "insert into fcm_info values('".$fcm_token."');";
$sql="INSERT INTO fcm_info(empid,fcm_token) VALUES ('$empid','".$fcm_token."');";
 
mysqli_query($con,$sql);
mysqli_close($con);
           

 }

 


?>
