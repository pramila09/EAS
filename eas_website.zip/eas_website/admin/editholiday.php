<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{
  header('location: index.php');
}
else{
if(isset($_POST['update']))
{
$holid=intval($_GET['holid']);    
$holtype=$_POST['holidaytype'];
$holstart=$_POST['startdate'];
$holend=$_POST['enddate'];

$sql="update holiday set Type=:holtype,StartDate=:holstart,EndDate=:holend where id=:holid";

$query = $dbh->prepare($sql);

$query->bindParam(':holtype',$holtype,PDO::PARAM_STR);
$query->bindParam(':holstart',$holstart,PDO::PARAM_STR);
$query->bindParam(':holend',$holend,PDO::PARAM_STR);
$query->bindParam(':holid',$holid,PDO::PARAM_STR);

$query->execute();
$msg="Holiday updated Successfully!";

}?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
</head>
<body>
	<?php include('includes/header.php');?>
	<div class="header-style">Edit Holiday Details..</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="chngpwd" method="post"><?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?><br> 
                <?php 
                $did=intval($_GET['holid']);
                $sql = "SELECT * from holiday WHERE id=:holid";
                $query = $dbh -> prepare($sql);
                $query->bindParam(':holid',$did,PDO::PARAM_STR);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>     

  				<input type="text" name="holidaytype" id="holidaytype" value="<?php echo htmlentities($result->Type);?>" autocomplete="off" required>

  				<input type="Date" name="startdate" id="startdate" value="<?php echo htmlentities($result->StartDate);?>" autocomplete="off" required>

  				<input type="Date" name="enddate" id="enddate" value="<?php echo htmlentities($result->EndDate);?>" autocomplete="off" required><?php }} ?>

  				<input class="button button2" type="submit" name="update" value="Update">
  			</form>
  		</div>
	</div>

</body>
</html>
<?php } ?>