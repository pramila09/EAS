<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{
  header('location: index.php');
}
else{
if(isset($_POST['update']))
{
$eveid=intval($_GET['evid']);    
$evname=$_POST['eventname'];
$evtype=$_POST['eventtype'];
$evstart=$_POST['startdate'];
$evend=$_POST['enddate'];
$location=$_POST['location'];

$sql="update events set evName=:evname,Category=:evtype,StartDate=:evstart,EndDate=:evend,Location=:location where id=:eveid";

$query = $dbh->prepare($sql);
$query->bindParam(':evname',$evname,PDO::PARAM_STR);
$query->bindParam(':evtype',$evtype,PDO::PARAM_STR);
$query->bindParam(':evstart',$evstart,PDO::PARAM_STR);
$query->bindParam(':evend',$evend,PDO::PARAM_STR);
$query->bindParam(':location',$location,PDO::PARAM_STR);
$query->bindParam(':eveid',$eveid,PDO::PARAM_STR);
$query->execute();

$msg="Event updated Successfully!";
}?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
</head>
<body>
	<?php include('includes/header.php');?>
	<div class="header-style">Edit Event Details..</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="chngpwd" method="post"><?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?><br> 
                <?php 
                $did=intval($_GET['evid']);
                $sql = "SELECT * from events WHERE id=:eveid";
                $query = $dbh -> prepare($sql);
                $query->bindParam(':eveid',$did,PDO::PARAM_STR);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>     

  				<input type="text" name="eventname" id="eventname" value="<?php echo htmlentities($result->evName);?>" autocomplete="off" required>

  				<input type="text" name="eventtype" id="eventtype" value="<?php echo htmlentities($result->Category);?>" autocomplete="off" required>

  				<input type="Date" name="startdate" id="startdate" value="<?php echo htmlentities($result->StartDate);?>" autocomplete="off" required>

  				<input type="Date" name="enddate" id="enddate" value="<?php echo htmlentities($result->EndDate);?>" autocomplete="off" required>

  				<input type="text" name="location" id="location" value="<?php echo htmlentities($result->Location);?>" autocomplete="off" required><?php }} ?>

  				<input class="button button2" type="submit" name="update" value="Update">
  			</form>
  		</div>
	</div>

</body>
</html>
<?php } ?>