<?php
session_start();
if(!isset($_SESSION["username"]))
	die("not logged in");
$username=$_SESSION["username"];
$empid=$_SESSION["empid"];
$Fname=$_SESSION["Fname"];
$emailid=$_SESSION["emailid"];
$department=$_SESSION["department"];

     include 'config.inc.php';
	echo $empid; 
	echo $Fname;
	echo $emailid;
	echo $department;



     if(isset($_POST['fromdate'], $_POST['todate'], $_POST['description'], $_POST['leavetype']))
     {
		  // Innitialize Variable
	   	  $fromdate = $_POST['fromdate'];
          $todate = $_POST['todate'];
		  $description = $_POST['description'];
		  $leavetype = $_POST['leavetype'];
		
		  
                  

		  
		  // Query database for row exist or not
		 
		  $sql = "INSERT INTO tbleaves (fromdate, todate, description, leavetype, empid, empName, department, email) VALUES ('$fromdate','$todate','$description', '$leavetype' , '$empid', '$Fname', '$department','$emailid');" ;
		  $stmt = $conn->prepare($sql);
          $stmt->bindParam(':fromdate', $fromdate, PDO::PARAM_STR);
          $stmt->bindParam(':todate', $todate, PDO::PARAM_STR);
		  $stmt->bindParam(':description',$description, PDO::PARAM_STR);
		  $stmt->bindParam(':leavetype',$leavetype,PDO::PARAM_STR);
		  $stmt->bindParam(':empid',$empid,PDO::PARAM_STR);
		  $stmt->bindParam(':Fname',$Fname, PDO::PARAM_STR);
		  $stmt->bindParam(':department',$department,PDO::PARAM_STR);
		  $stmt->bindParam(':emailid',$emailid,PDO::PARAM_STR);
          $stmt->execute();
  
          if($stmt->rowCount())
          {
			 $result="true";	
          }  
          elseif(!$stmt->rowCount())
          {
			  	$result="false";
          }
		  
		  // send result back to android
   		  echo 'Data submitted';
		  
		 
  	}
	
?>


