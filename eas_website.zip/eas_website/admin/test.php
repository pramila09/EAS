 <?php include('includes/empaddress.php');?>
<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
if(isset($_POST['add']))
{
$empId=$_POST['empiid'];
$fname=$_POST['firstName'];  
$email=$_POST['email']; 
$password=$_POST['password']; 
$department=$_POST['department']; 
$province=$_POST['province']; 
$district=$_POST['district']; 
$municipality=$_POST['municipality'];
$mobileno=$_POST['mobileno']; 
$ward=$_POST['wardno']; 

$sql="INSERT INTO tblemployees(EmpId,Fname,emailid,password,department,Province,District,Muncipality,phnumber,Ward,RemainingDays) VALUES(:empId,:fname,:email,:password,:department,:province,:district,:municipality,:mobileno,:ward,15)";


$query = $dbh->prepare($sql);
$query->bindParam(':empId',$empId,PDO::PARAM_STR);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->bindParam(':department',$department,PDO::PARAM_STR);
$query->bindParam(':province',$province,PDO::PARAM_STR);
$query->bindParam(':district',$district,PDO::PARAM_STR);
$query->bindParam(':municipality',$municipality,PDO::PARAM_STR);
$query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
$query->bindParam(':ward',$ward,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();

if($lastInsertId)
{
$msg="Employee record added Successfully!";
}
else 
{
$error="Something went wrong. Please try again!";
}}?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/employeestyle.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<script>
		function valid(){
		if(document.addemp.password.value!= document.addemp.confirmpassword.value){
		alert("New Password and Confirm Password Field do not match  !!");
		document.addemp.confirmpassword.focus();
		return false;
			}
		return true;
		}
</script>

</head>
<body>
	<?php include('includes/header.php')?>
	<div class="employee-header-style">App Register</div>

	<div class="employee-card col-3">
  		<div class="employee-container">
  			<div class = information>General Information:</div>
  				<form name="chngpwd" method="post"><?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?><br>

<?php
    try{
       include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		catch(Exception $e)
		{
		    die(print_r( $e->getMessage()));
		}
$eid=intval($_GET['empid']);
$tsql="SELECT * FROM tblEmployee,tblDepartment WHERE  EmployeeId = $eid AND tblDepartment.DepartmentId = tblEmployee.DepartmentId";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt=1;
if ($getResults-> rowCount() > 0) {
foreach($results as $row){?>

                	<input type="text" id="empiid" name="empiid" autocomplete="off" required readonly value="<?php echo $row['EmployeeId']?>">

  					<input style = "margin-left: 3%;" type="text" id="firstName" name="firstName" placeholder="Full name" autocomplete="off" required readonly value="<?php echo $row['EmpName']?>">
				    

				    <div class = information>Address:</div>
				    <select id="province" name="province" class="dropdown-select" autocomplete="off" required>
					    <option value="">Province No..</option>
					    <?php
							foreach($arrCountry as $province){
								?>
								<option value="<?php echo $province['id']?>"><?php echo $province['name']?></option>
								<?php
							}
							?>
				    </select>
				    <select id="district" name="district" style = "margin-left: 3%;" class="dropdown-select" autocomplete="off" required>
					    <option value="">District..</option>
				    </select>
				    <select id="municipality" name="municipality" style = "margin-left: 3%;" class="dropdown-select" autocomplete="off" required>
					    <option value="">Municipality/VC..</option>
				    </select>
				    <input  type = "No" id="wardno" name="wardno" placeholder="Ward No." autocomplete="off" required />

				    <div class = information>Contact Information:</div>
				    <input id="phone" name="mobileno" type="phone" placeholder="Phone Number" autocomplete="off" required>
				    <input style = "margin-left: 3%;" name="email" type="email" id="email" onBlur="checkAvailabilityEmailid()" placeholder="Email Address" autocomplete="off" required>

				    <div class = information>Other:</div>
				    <input name="department" type="text" id="department" placeholder="Department" autocomplete="off" required readonly value="<?php echo $row['DepartmentName']?>">

				    <input style="margin-left: 3%;" type="password" id="password" name="password" placeholder="Password" autocomplete="off" required>
  					<input style="margin-left: 3%;" type="password" id="confirm" name="confirmpassword" placeholder="Confirm Password" autocomplete="off" required>

  					<?php $cnt++; } } ?>
  					<input class="button button2" id="add" type="submit" name="add" value="Add" onclick="return valid();">


  				</form>
  		</div>
	</div>
	<script>
	$(document).ready(function(){
		jQuery('#province').change(function(){
			var id=jQuery(this).val();
			if(id=='-1'){
				jQuery('#district').html('<option value="">Select District..</option>');
			}else{
				$("#divLoading").addClass('show');
				jQuery('#district').html('<option value="">Select District..</option>');
				jQuery('#municipality').html('<option value="">Select Municipality/VC..</option>');
				jQuery.ajax({
					type:'post',
					url:'includes/get_address.php',
					data:'id='+id+'&type=district',
					success:function(result){
						$("#divLoading").removeClass('show');
						jQuery('#district').append(result);
					}
				});
			}
		});
		jQuery('#district').change(function(){
			var id=jQuery(this).val();
			if(id=='-1'){
				jQuery('#municipality').html('<option value="">Select Municipality/VC..</option>');
			}else{
				$("#divLoading").addClass('show');
				jQuery('#municipality').html('<option value="">Select Municipality/VC..</option>');
				jQuery.ajax({
					type:'post',
					url:'includes/get_address.php',
					data:'id='+id+'&type=municipality',
					success:function(result){
						$("#divLoading").removeClass('show');
						jQuery('#municipality').append(result);
					}
				});
			}
		});
	});
	</script>
</body>
</html>
<?php } ?> 
