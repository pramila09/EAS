<?php
require "init.php";
$message= $_POST['message'];
$title = $_POST['title'];
$path_to_fcm = 'https://fcm.googleapis.com/fcm/send';
$server_key="AIzaSyBSPo4QbcaHNxg81i3GOf4DTlyYli9PGTM";
  $sql = "Select fcm_token From fcm_info";
        $result = mysqli_query($con,$sql);
        $tokens = array();
//var_dump(result);
        if(mysqli_num_rows($result) > 0 ){
                while ($row = mysqli_fetch_assoc($result)) {
                        $tokens[] = $row["fcm_token"];
                }
        }
  



$headers = array(
                        'Authorization:key ='.$server_key ,
                        'Content-Type: application/json'
                        );

$fields = array(
                         'registration_ids' => $tokens,
                         'notification' => array(
                         'title'=> $title,
                         'body'=>$message,
                        'click_action'=>'com.example.pramila.eas_TARGET_NOTIFICATION'
                    )
                        
                  );
$payload=json_encode($fields);

                
           $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, $path_to_fcm);
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
       curl_setopt($ch, CURLOPT_POSTFIELDS,$payload);
       $result = curl_exec($ch);
      if(!$result)
//echo "server send fail";
header("Location: sendnotification.php?success=0");
else
echo "result $result";
//echo "<br/>Message sent!";
header("Location: sendnotification.php?success=1");
mysqli_close($con);;
        

     
       
 ?> 

