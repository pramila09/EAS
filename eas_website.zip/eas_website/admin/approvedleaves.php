<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
</head>
<body>
	<?php include('includes/header.php')?>

</body>
</html>