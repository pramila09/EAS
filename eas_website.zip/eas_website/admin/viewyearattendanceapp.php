<?php

session_start();
if(!isset($_SESSION["username"]))
    die("not logged in");
$username=$_SESSION["username"];
$empid=$_SESSION["empid"];

if(isset($_GET["count"]))
$count=$_GET["count"];
else{
$count=200;
}
if(isset($_POST["year"]))
{

    $alldate=$_POST["year"];
   
$dates=explode("-",$alldate);
$year=$dates[0];
$month=$dates[1];
$day=$dates[2];

}
else{
   
$year=2019;
}
$nextm=$month+1;
     include 'config.inc.php';
    
    //$eid = 1;
    try{
   // include 'config.mssql.php';
    //$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);   
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn=new PDO("sqlsrv:Server=WINDOWS-UPVJIVE\PRAMILASQL,52704;Database=AMS2_project3x", "", "");
        }
        catch(Exception $e)
        {
            die(print_r( $e->getMessage()));
        }
/*$tsql="SELECT TOP $count tblAttendanceLog.AttendanceLogId,tblAttendanceLog.EnrollNo,tblAttendanceLog.EnrollTime,tblAttendanceLog.EnrollDate,tblEmployee.EmpName,tblEmployee.EmployeeId,tblEmployee.EnrollNo FROM tblAttendanceLog,tblEmployee WHERE
tblAttendanceLog.EnrollDate >= '$year-01-01' AND tblAttendanceLog.EnrollDate < '$nextyear-01-01' AND tblEmployee.EmployeeId = $empid AND tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo ORDER BY AttendanceLogId desc";*/
//echo "$year $nextyear";
//echo $tsql;
//die();
//$tsql_params = array(':Empid' => $empid);


 $tsql="SELECT tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime FROM tblEmployee,tblAttendanceLog WHERE tblAttendanceLog.EnrollDate < '$year-$nextm-01' AND tblAttendanceLog.EnrollDate >= '$year-$month-01' AND tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo and tblEmployee.EmployeeId=$empid ORDER BY tblAttendanceLog.EnrollDate desc";


try{
$getResults=$conn->prepare($tsql);
$getResults->execute();}
catch (PDOException $ex) {        
        die(json_encode($response));
    }
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt=1;
 $response = array();
if ($results) {
    
        foreach($results as $row) {
            $Empid = array();
            $Empid["EnrollDate"] = $row["EnrollDate"];
            $Empid["EnrollTime"] = $row["EnrollTime"];
       

            //update our repsonse JSON data
            array_push($response, $Empid);
        }

        // echoing JSON response
        echo json_encode($response);
}else {
        die(json_encode($response));
    }
    
?>

    
    

