<?php

session_start();
$host="localhost";
$username="root";
$password="";
$db="employees";
$con=mysqli_connect($host,$username,$password,$db) or die("Unable to connect");
if(mysqli_connect_error($con))
{
	echo "Failed to connect";
}
$query=mysqli_query($con,"SELECT * FROM events");
if($query)
{
	while($row=mysqli_fetch_array($query))
	{
		$flag[]=$row;
	}
	print(json_encode($flag));
}
mysqli_close($con);
?>