<?php include('includes/empaddress.php');?>
<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
if(isset($_POST['add']))
{

$fullname=$_POST['empName'];  
$departmentid=$_POST['departid']; 
$department=$_POST['deptname']; 
$email=$_POST['email']; 
$password=$_POST['password']; 

$sql="INSERT INTO tblhod(FullName,Deptid,Department,Email,Password) VALUES(:fullname,:departmentid,:department,:email,:password)";

$query = $dbh->prepare($sql);
$query->bindParam(':fullname',$fullname,PDO::PARAM_STR);
$query->bindParam(':departmentid',$departmentid,PDO::PARAM_STR);
$query->bindParam(':department',$department,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();

if($lastInsertId)
{
$msg="Hod record added Successfully!";
}
else 
{
$error="Something went wrong. Please try again!";
}}?>
<?php try{
    include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		catch(Exception $e)
		{
		    die(print_r( $e->getMessage()));
		}?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="css/employeestyle.css">
	<link rel="stylesheet" type="text/css" href="css/employeestyle.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script>
		function valid(){
		if(document.addemp.password.value!= document.addemp.confirmpassword.value){
		alert("New Password and Confirm Password Field do not match  !!");
		document.addemp.confirmpassword.focus();
		return false;
			}
		return true;
		}
</script>
</head>
<body>
	<?php include('includes/header.php');?>
	<div class="employee-header-style">Hod Register</div>
	<div class="employee-card col-3">
  		<div class="employee-container">
  				<form name="chngpwd" method="post"><?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?><br>

  					<?php
    
$deid=intval($_GET['depid']);
$tsql="SELECT * FROM tblDepartment WHERE  DepartmentId = $deid";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt=1;
if ($getResults-> rowCount() > 0) {
foreach($results as $row){?>

                	<input type="text" id="departid" name="departid" autocomplete="off" required readonly value="<?php echo $row['DepartmentId']?>">
                	<input style = "margin-left: 3%;" type="text" id="deptname" name="deptname" autocomplete="off" required readonly value="<?php echo $row['DepartmentName']?>">
                	<?php $cnt++; }}?>
                	<select name="empName" class="dropdown-select" style = "margin-left: 3%;" required>
                		<option>Select Employee</option>
                	<?php    
					$d=intval($_GET['depid']);
					$sql="SELECT * FROM tblEmployee WHERE  DepartmentId = $d";
					$getResult=$conn->prepare($sql);
					$getResult->execute();
					ini_set('memory_limit', '-1');
					$result=$getResult->fetchAll(PDO::FETCH_BOTH);
					$cnt2=1;
					if ($getResult-> rowCount() > 0) {
					foreach($result as $rows){?>
						<option value="<?php echo $rows['EmpName'];?>"><?php echo $rows['EmpName'];?></option>
						<?php $cnt2++; }}?>
					</select>

					<input type="email" id="email" name="email" autocomplete="off" required placeholder ="Email">
					<input style = "margin-left: 3%;" type="password" id="password" name="password" autocomplete="off" required placeholder ="Password">
					<input style="margin-left: 3%;" type="password" id="confirm" name="confirmpassword" placeholder="Confirm Password" autocomplete="off" required>

					<input class="button button2" id="add" type="submit" name="add" value="Add" onclick="return valid();">

  				</form>
  			</div>
  		</div>
</body>
</html>
<?php }?>