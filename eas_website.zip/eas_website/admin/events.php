<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
  if(isset($_GET['inid']))
    {
    $id=$_GET['inid'];
    $status=0;
    $sql = "update events set Status=:status  WHERE id=:id";
    $query = $dbh->prepare($sql);
    $query -> bindParam(':id',$id, PDO::PARAM_STR);
    $query -> bindParam(':status',$status, PDO::PARAM_STR);
    $query -> execute();
    header('location:events.php');
    }



//code for active employee
if(isset($_GET['id']))
    {
    $id=$_GET['id'];
    $status=1;
    $sql = "update events set Status=:status  WHERE id=:id";
    $query = $dbh->prepare($sql);
    $query -> bindParam(':id',$id, PDO::PARAM_STR);
    $query -> bindParam(':status',$status, PDO::PARAM_STR);
    $query -> execute();
    header('location:events.php');
    }

if(isset($_GET['del']))
    {
    $id=$_GET['del'];
    $sql = "delete from  events  WHERE id=:id";
    $query = $dbh->prepare($sql);
    $query -> bindParam(':id',$id, PDO::PARAM_STR);
    $query -> execute();
    $msg="Event record deleted!";
    }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
  <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php');?>
	<div class="event-header-style">Event Details..</div>
  <a class="col-3" href="addevent.php"><span class="new-event">New Event</span></a>

	<div class="event-datatable-card">
  		<div class="event-datatable-container">
  			<form name="chngpwd" method="post"><?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
  					<table id="example" class="display" style="width:100%">
        				<thead>
            				<tr>
				                        <th>Sr no</th>
                                <th>Name</th>
                                <th>Type</th>
                                <th>From-To</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Registed At</th>      
                                <th>Action</th>
            				    </tr>
        				</thead>
                <tbody>
                    <?php $sql = "SELECT evName, Category, StartDate, EndDate, Location, Status, RegDate, id from events";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>
                    <tr>
                                            <td> <?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($result->evName);?></td>
                                            <td><?php echo htmlentities($result->Category);?></td>
                                            <td><?php echo htmlentities($result->StartDate);?>&nbsp;to
                                            <?php echo htmlentities($result->EndDate);?></td>
                                            <td><?php echo htmlentities($result->Location);?></td>
                                            <td><?php $stats=$result->Status;
                                      if($stats){
                                             ?>
                                                 <a class="waves-effect waves-green btn-flat m-b-xs">Active</a>
                                                 <?php } else { ?>
                                                 <a class="waves-effect waves-red btn-flat m-b-xs">Inactive</a>
                                                 </td>
                                                 <?php } ?>


                                             </td>
                                              <td><?php echo htmlentities($result->RegDate);?></td>
                                            <td><a href="editevent.php?evid=<?php echo htmlentities($result->id);?>"><i class="fas fa-user-edit"></i></a>
                                              <a href="events.php?del=<?php echo htmlentities($result->id);?>" onclick="return confirm('Do you want to delete?');"><i class="fas fa-trash"></i></a>
                                        <?php if($result->Status==1){?>

                    <a href="events.php?inid=<?php echo htmlentities($result->id);?>" onclick="return confirm('Are you sure you want to inactive this event?');"><i class="fas fa-times"></i></a>

                    <?php } else {?>

                                            <a href="events.php?id=<?php echo htmlentities($result->id);?>" onclick="return confirm('Are you sure you want to active this event?');"><i class="fas fa-check"></i></a>
                                            <?php } ?> </td>
                                        </tr>
                                           
                                        </tr>
                                    <?php $cnt++;} }?>
                  </tbody>
        			</table>
  			</form>
  		</div>
	</div>
  <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>
</body>
</html>
<?php } ?>