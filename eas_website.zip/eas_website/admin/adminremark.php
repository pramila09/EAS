<?php include('includes/config.php');

if(isset($_POST['update']))
{
$leveid=intval($_GET['levid']);    
$status=$_POST['status'];

$sql="update tbleaves set Status=:status where id=:leveid";

$query = $dbh->prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':leveid',$leveid,PDO::PARAM_STR);
$query->execute();

echo "<script type = 'text/javascript'> document.location = 'allleaves.php'; </script>";
}?>
</html><!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="css/employeestyle.css">
</head><body>
	<?php include('includes/header.php')?>
	<div class="datatable-header-style">Admin Action</div>

	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="post">
<?php 
$lid=intval($_GET['levid']);
$sql = "SELECT * from tbleaves WHERE id=:lid";
$query = $dbh -> prepare($sql);
$query->bindParam(':lid',$lid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>
  				<select name="status" id="status" class="dropdown-select" autocomplete="off" required>
              <option selected disabled>Choose Action..</option>
              <option value="1">Approved</option>
              <option value="2">Not Approved</option>
          </select>
          <?php $cnt++; }}?>
          <input class="button button2" id="update" type="submit" name="update" value="Update">
  			</form>
  		</div>
  	</div>

</body>
</html>