<?php
try{
      include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
}

if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$query="SELECT AttendanceLogId FROM tblAttendanceLog";
//echo $query;
//$rows=sqlsrv_num_rows($query);
$getResults=$conn->prepare($query);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$row=1;
//echo $row= $getResults-> rowCount();

$page_rows=4;
$last=ceil($row/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; }
$max = ($pagenum - 1) * $page_rows;

                             echo    $tsql="WITH tblAttendanceLog AS

            (SELECT ROW_NUMBER() OVER(ORDER BY AttendanceLogId) AS

                  EnrollNo,

                  EnrollDate,

                 EnrollTime

       FROM tblAttendanceLog)

         SELECT * FROM tblAttendanceLog

         WHERE EnrollNo BETWEEN ? AND ? + 1";
                                 echo $tsql;
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt = 1;

if($getResults->rowCount() > 0)
								{
								foreach($results as $result)
								{
										 echo htmlentities($EnrollDate=$result['EnrollDate']);
										 echo htmlentities($EnrollDate=$result['EnrollTime']);
										 echo "<br>";
										 $cnt++;
//$total = $getResults-> rowCount();
//echo htmlentities($total);
/*
$result=sqlsrv_query($conn,$tsql);										 
while($info = sqlsrv_fetch_array( $result,SQLSRV_FETCH_ASSOC )) 
{ 
print $info['EnrollDate']; 
echo "<br>";
} */
}}
echo "<p>";
echo "--Page $pagenum of $last--<p>";
if($pagenum==1){}
else
{
	echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=1'> <<-First</a> ";
echo " ";
$previous = $pagenum-1;
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$previous'> <-Previous</a> ";
} 

//just a spacer
echo " ---- ";

//This does the same as above, only checking if we are on the last page, and then generating the Next and Last links
if ($pagenum == $last) 
{
} 
else {
$next = $pagenum+1;
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$next'>Next -></a> ";
echo " ";
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$last'>Last ->></a> ";
} 

 ?>