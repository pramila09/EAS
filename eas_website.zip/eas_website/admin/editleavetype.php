<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
if(isset($_POST['update']))
{
$lid=intval($_GET['lid']);
$leavetype=$_POST['leavetype'];
$description=$_POST['description'];
$sql="update tbleavestypes set leavetype=:leavetype,description=:description where id=:lid";
$query = $dbh->prepare($sql);
$query->bindParam(':leavetype',$leavetype,PDO::PARAM_STR);
$query->bindParam(':description',$description,PDO::PARAM_STR);
$query->bindParam(':lid',$lid,PDO::PARAM_STR);
$query->execute();

$msg="Leave type updated Successfully!";
}?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin</title>
  <link rel="stylesheet" type="text/css" href="css/allstyle.css">
</head>
<body>
  <?php include('includes/header.php')?>
  <div class="header-style">Update Leave details</div>

  <div class="login-card">
      <div class="login-container">
        <form name="chngpwd" method="post">
          <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
                <?php 
                    $lid=intval($_GET['lid']);
                    $sql = "SELECT * from tbleavestypes where id=:lid";
                    $query = $dbh -> prepare($sql);
                    $query->bindParam(':lid',$lid,PDO::PARAM_STR);
                    $query->execute();
                    $results=$query->fetchAll(PDO::FETCH_OBJ);
                    $cnt=1;
                    if($query->rowCount() > 0)
                    {
                    foreach($results as $result)
                    {?>    <?php }} ?>   

          <input type="text" name="leavetype" id="leavetype" value="<?php echo htmlentities($result->leavetype);?>" autocomplete="off" required>
          <textarea type="text" name="description" id="textarea" placeholder="description..." autocomplete="off" required><?php echo htmlentities($result->description);?></textarea>
          <input class="button button2" type="submit" name="update" value="Update">
        </form>
      </div>
  </div>

</body>
</html>
<?php } ?>