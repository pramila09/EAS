<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql = "delete from  tblhod  WHERE id=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();
$msg="Hod record deleted!";

}
    ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
  	<link rel="stylesheet" type="text/css" href="css/employeestyle.css">
  	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php')?>
  <?php $did=intval($_GET['deptid']);?>
  <div class="datatable-header-style">HODs</div>
  <div class="datatable-card">
    <a href="addhod.php?depid=<?php echo($did);?>"><span>Add New Hod</span></a>
      <div class="datatable-container" style="margin-top: 20px;">
        <form name="chngpwd" method="post" action="hods.php"><?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?><br>

          <table id="example" class="display" style="width:100%;">
                <thead>
                    <tr>
                                <th>Sr no</th>
                                <th>Hod Name</th>
                                <th>Department</th>
                                <th>Email</th>
                                <th>Action</th>
                    </tr>
                </thead>
                 <tbody>
                <?php $sql = "SELECT * from tblhod where Deptid = $did";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>
                    <tr>
                                            <td> <?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($result->FullName);?></td>
                                            <td><?php echo htmlentities($result->Department);?></td>
                                            <td><?php echo htmlentities($result->Email);?></td>
                                            <td>
                                              <a href="hods.php.php?del=<?php echo htmlentities($result->id);?>" onclick="return confirm('Do you want to delete');"><i class="fas fa-trash"></i></a></td>
                                        </tr>
                                    <?php $cnt++;} }?>
                  </tbody>
              </table>
         
                  
        
    </form>
</div>
</div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>

</body>
</html>
<?php }?>
