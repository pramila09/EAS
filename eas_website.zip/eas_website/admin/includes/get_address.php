<?php
include('address.php');
$id=$_POST['id'];
$type=$_POST['type'];

if($type=='municipality'){
	$sql="select id,name from municipality where district_id='$id'";
}else{
	$sql="select id,name from district where province_id='$id'";
}
$stmt=$con->prepare($sql);
$stmt->execute();
$arr=$stmt->fetchAll(PDO::FETCH_ASSOC);
$html='';
foreach($arr as $list){
	$html.='<option value='.$list['id'].'>'.$list['name'].'</option>';
}
echo $html;
?>