<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<header>
		<a href="dashboard.php"><img src="images/logo.png" class="img-responsive"></a>
		<span class="welcome">welcome back, </span>
		<span class="wel-admin">admin!!</span>
	</header>

	<nav>
		<ul>
			<li class="active"><a href="dashboard.php">dashboard</a></li>

			<li><a>leave</a>
				<ul>
					<li><a href="addleave.php">add..</a></li>
					<li><a href="manageleave.php">manage..</a></li>
				</ul>
			</li>

			<li><a href="manageemployee.php">employee</a>
				
			
			</li>

			<li><a href="managedepartment.php">department</a>
				
			</li>

			<li><a href="attendanceindex.php">attendance</a></li>
			<li><a href="">attendance report</a>
			<ul>
				<li><a href="viewattendanceyearly.php">view yearly attendance</a></li>
				<li><a href="viewmonthattendance.php">view monthly attendance</a></li>
				<li><a href="viewAttendance.php">view daily attendance</a></li>
			</ul>
             </li>
			<li><a href="">send notification</a>
            <ul>
				<li><a href="sendnotification.php">broadcast notification </a></li>
				<li><a href="sendnotificationsingle.php">single push notification</a></li>
				
			</ul>
			</li>

			<li><a href="events.php">events</a>
			
					
					
				
			</li>

			<li><a href="changepassword.php">change password</a></li>

			<li><a href="index.php">logout</a></li>
		</ul>
	</nav>

</body>
</html>