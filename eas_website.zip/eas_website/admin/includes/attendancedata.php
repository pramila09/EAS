<?php 
$servername = "KINGMINAS\MINASSERVER";
$connectionInfo = array( "Database"=>"AMS2_project3x");
$conn =sqlsrv_connect( $servername, $connectionInfo);

if( $conn ){
	
}
else{
	echo "Connection fail.<br />";
	die( print_r( sqlsrv_errors(), true));
}
?>