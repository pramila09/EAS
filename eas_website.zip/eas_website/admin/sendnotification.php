


<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>

	<?php include('includes/header.php')?>
	<div class="header-style-dashboard">Send Notification</div>
	<div class="d-card1">
		

<html>

<body>
<form action="send_notification.php" method="post">
<table>
<tr>
<td> Title : </td><td><input type="text" name="title" required/>
</td>
</tr>

<tr>
<td> Message: </td><td><input type="text" name="message" required /></td>
</tr>

<td><input type="submit" value="Submit"/>
<?php
	if(isset($_GET["success"])){
		if($_GET["success"]==1)
			echo "Result: Notification was sent!";
		else
			echo "Result: Notification was not sent!";
	}
	?>

</td>
</tr>


</table>
</form>
</body>
</html>
</span>
</div>
</body>
</html>
