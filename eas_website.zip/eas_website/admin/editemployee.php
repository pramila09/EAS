<?php include('includes/empaddress.php');?>
<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
$eid=intval($_GET['empid']);
if(isset($_POST['update']))
{

$fname=$_POST['firstName'];
$lname=$_POST['lastName'];   
$gender=$_POST['gender']; 
$dob=$_POST['dob']; 
$department=$_POST['department']; 
$province=$_POST['province']; 
$district=$_POST['district']; 
$municipality=$_POST['municipality']; 
$wardno=$_POST['wardno']; 
$mobileno=$_POST['mobileno']; 
$sql="update tblemployee set Fname=:fname,Lname=:lname,gender=:gender,dob=:dob,department=:department,Provine=:province,District=:district,Muncipality=:municipality,Ward=:wardno,phnumber=:mobileno where id=:eid";
$query = $dbh->prepare($sql);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':lname',$lname,PDO::PARAM_STR);
$query->bindParam(':gender',$gender,PDO::PARAM_STR);
$query->bindParam(':dob',$dob,PDO::PARAM_STR);
$query->bindParam(':department',$department,PDO::PARAM_STR);
$query->bindParam(':address',$address,PDO::PARAM_STR);
$query->bindParam(':city',$city,PDO::PARAM_STR);
$query->bindParam(':country',$country,PDO::PARAM_STR);
$query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
$query->bindParam(':eid',$eid,PDO::PARAM_STR);
$query->execute();
$msg="Employee record updated Successfully";
}

    ?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/employeestyle.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</head>
<body>
	<?php include('includes/header.php')?>
	<div class="employee-header-style">Update Employee Details</div>

	<div class="employee-card col-3">
  		<div class="employee-container">
  			<div class = information>General Information:</div>
  				<form name="chngpwd" method="post"><?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
                <?php 
					$eid=intval($_GET['empid']);
					$sql = "SELECT * from  tblemployee where id=:eid";
					$query = $dbh -> prepare($sql);
					$query -> bindParam(':eid',$eid, PDO::PARAM_STR);
					$query->execute();
					$results=$query->fetchAll(PDO::FETCH_OBJ);
					$cnt=1;
					if($query->rowCount() > 0)
					{
					foreach($results as $result)
					{               ?> 

  					<input type="text" name="empcode" id="empcode" value="<?php echo htmlentities($result->EmployeeId);?>" autocomplete="off" readonly>	

  					<input style="margin-left: 3%;" type="text" id="firstName" name="firstName" value="<?php echo htmlentities($result->Fname);?>" autocomplete="off" required>

  					<input style="margin-left: 3%;" type="text" id="lastName" name="lastName" value="<?php echo htmlentities($result->Lname);?>" autocomplete="off" required>

  					<select name="gender" class="dropdown-select" autocomplete="off" required>
					    <option value="<?php echo htmlentities($result->gender);?>"><?php echo htmlentities($result->gender);?></option>
					    <option value="Male">Male</option>
					    <option value="Female">Female</option>
					    <option value="Other">Other</option>
				    </select>

				    <input style="margin-left: 3%;" type = "date" id="birthdate" name="dob" value="<?php echo htmlentities($result->dob);?>"  autocomplete="off" required />
				    

				    <div class = information>Address:</div>
				    <select id="province" name="province" class="dropdown-select" autocomplete="off" required>
					    <option value="<?php echo htmlentities($result->Province);?>"><?php echo htmlentities($result->Province);?></option>
					    <?php
							foreach($arrCountry as $province){
								?>
								<option value="<?php echo $province['id']?>"><?php echo $province['name']?></option>
								<?php
							}
							?>
					    
				    </select>
				    <select id="district" name="district" style = "margin-left: 3%;" class="dropdown-select" autocomplete="off" required>
					    <option value="<?php echo htmlentities($result->District);?>"><?php echo htmlentities($result->District);?></option>
				    </select>
				    <select id="municipality" name="municipality" style = "margin-left: 3%;" class="dropdown-select" autocomplete="off" required>
					    <option value="<?php echo htmlentities($result->Muncipality);?>"><?php echo htmlentities($result->Muncipality);?></option>
				    </select>
				    <input  type = "No" id="wardno" name="wardno" value="<?php echo htmlentities($result->Ward);?>" autocomplete="off" required />

				    <div class = information>Contact Information:</div>
				    <input id="phone" name="mobileno" type="phone" value="<?php echo htmlentities($result->phnumber);?>" autocomplete="off" required>
				    <input style = "margin-left: 3%;" name="email" type="text" id="email" autocomplete="off" value="<?php echo htmlentities($result->emailid);?>" readonly>

				    <div class = information>Other:</div>
				    <select name="department" class="dropdown-select" autocomplete="off" required>
					    <option value="<?php echo htmlentities($result->department);?>"><?php echo htmlentities($result->department);?></option>
					    <?php $sql = "SELECT departmentName from tbldepartments";
							$query = $dbh -> prepare($sql);
							$query->execute();
							$results=$query->fetchAll(PDO::FETCH_OBJ);
							$cnt=1;
							if($query->rowCount() > 0)
							{
							foreach($results as $resultt)
							{   ?>                                            
							<option value="<?php echo htmlentities($resultt->departmentName);?>"><?php echo htmlentities($resultt->departmentName);?></option>
							<?php }} ?>
				    </select>
				    <?php }}?>
  					<input style = "margin-left: 3%;" class="button button2" id="update" type="submit" name="update" value="Update">


  				</form>
  		</div>
	</div>
	<script>
	$(document).ready(function(){
		jQuery('#province').change(function(){
			var id=jQuery(this).val();
			if(id=='-1'){
				jQuery('#district').html('<option value="">Select District..</option>');
			}else{
				$("#divLoading").addClass('show');
				jQuery('#district').html('<option value="">Select District..</option>');
				jQuery('#municipality').html('<option value="">Select Municipality/VC..</option>');
				jQuery.ajax({
					type:'post',
					url:'includes/get_address.php',
					data:'id='+id+'&type=district',
					success:function(result){
						$("#divLoading").removeClass('show');
						jQuery('#district').append(result);
					}
				});
			}
		});
		jQuery('#district').change(function(){
			var id=jQuery(this).val();
			if(id=='-1'){
				jQuery('#municipality').html('<option value="">Select Municipality/VC..</option>');
			}else{
				$("#divLoading").addClass('show');
				jQuery('#municipality').html('<option value="">Select Municipality/VC..</option>');
				jQuery.ajax({
					type:'post',
					url:'includes/get_address.php',
					data:'id='+id+'&type=municipality',
					success:function(result){
						$("#divLoading").removeClass('show');
						jQuery('#municipality').append(result);
					}
				});
			}
		});
	});
	</script>	
</body>
</html>
<?php } ?> 
