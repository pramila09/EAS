

<?php
try{
      include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
}

$request=$_REQUEST;
$col=array(
            0=>"AttendanceLogId",
            1=>"EmployeeId",
            2=>"EmpName",
            3=>"EnrollDate",
            4=>"EnrollTime"
            
      
        );
$sql="SELECT count(distinct tblAttendanceLog.AttendanceLogId) as total FROM tblAttendanceLog,tblEmployee WHERE tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo";
try{
  $getResults1=$conn->prepare($sql);
  $getResults1->execute();
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$result1=$getResults1->fetchAll(PDO::FETCH_BOTH);

//$result=$getResults1->fetchAll();
$total=$result1[0]["total"];
$totalFilter=intval($total);

$searchsql ="WHERE ";
if(!empty($request['search']['value'])){
    //$searchsql.=" (AttendanceLogId Like '".$request['search']['value']."%' ";
    //$searchsql.=" (EnrollDate Like '".$request['search']['value']."%' ";
    //$searchsql.=" OR EnrollTime Like '".$request['search']['value']."%' ";
    $searchsql.=" EmpName Like '".$request['search']['value']."%' ";
}

$last=$request['start'];


$orderby=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  ";




$page_rows=$request['length'];
if(!empty($request['search']['value'])){
     $tsql="SELECT tblAttendanceLog.AttendanceLogId, tblEmployee.EmployeeId, tblEmployee.EmpName, tblAttendanceLog.EnrollDate, tblAttendanceLog.EnrollTime FROM tblAttendanceLog,tblEmployee $searchsql and  tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo $orderby
     OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY ";
                      }
                      else
 $tsql="SELECT tblAttendanceLog.AttendanceLogId, tblEmployee.EmployeeId, tblEmployee.EmpName, tblAttendanceLog.EnrollDate, tblAttendanceLog.EnrollTime FROM tblAttendanceLog,tblEmployee WHERE tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo $orderby OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY ";

                                // $tsql="SELECT tblAttendanceLog.AttendanceLogId, tblEmployee.EmployeeId, tblEmployee.EmpName, tblAttendanceLog.EnrollDate, tblAttendanceLog.EnrollTime FROM tblAttendanceLog,tblEmployee WHERE tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo ORDER BY AttendanceLogId desc";

try{
  $getResults=$conn->prepare($tsql);
  $getResults->execute();
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
//$cnt=1;

$data = array();
if ($results) {
  foreach($results as $row) {
    $Empid = array();
    $Empid[] = $row[0];
    $Empid[] = $row[1];
    $Empid[] = $row[2];
    $Empid[] = $row[3];
    $Empid[] = $row[4];
    
   // $Empid["name"] = "dinesh";

//$data[]=$Empid;
    //update our repsonse JSON data
    array_push($data, $Empid);
   
  }

  // echoing JSON response
  //echo json_encode($data);
}else {
  die(json_encode($data));
}
$json_data=array(
    "draw"=>intval($request['draw']),
    "recordsTotal"=>$total,
    "recordsFiltered"=>intval($totalFilter),
    "data"=>$data
);
echo json_encode($json_data);

?>

