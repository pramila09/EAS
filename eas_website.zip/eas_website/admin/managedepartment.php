<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
	

</head>
<body>
	<?php include('includes/header.php')?>
	<div class="datatable-header-style">Departments</div>
  <a class="col-3" href="adddepartment.php"><span class="dept-details">Details</span></a>
	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="POST">
  					<table id="example" class="display" style="width:100%">
        				<thead>
            				<tr>
				                        <th>Sr No</th>
                                <th>Dept Id</th>
                                <th>Dept Name</th>
                                <th>Hod</th>
                                
            				</tr>
        				</thead>
        					<tbody>
        						<?php
try{
       include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
}
                                 $tsql="SELECT * FROM tblDepartment";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt=1;
if ($getResults-> rowCount() > 0) {
foreach($results as $row){?>
    
    <tr><td><?php echo htmlentities($cnt);?></td></td><td><?php echo $row['DepartmentId'];?></td><td><?php echo $row['DepartmentName'];?><td><a href="hods.php?deptid=<?php echo $row['DepartmentId']?>">Hod Manage<i class="fas"></i></a></td></td>
    </tr>
    
<?php $cnt++; } }?>

        					</tbody>
        			</table>
  			</form>
  		</div>
	</div>

	<script type="text/javascript">
		$(document).ready(function() {
    $('#example').DataTable();
} );
	</script>

</body>
</html>