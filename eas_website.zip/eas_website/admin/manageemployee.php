
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php')?>
	<div class="datatable-header-style">All Employees Detail</div>
	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="post">
  					<table id="example" class="display" name="example" style="width:100%">
        				<thead>
            				<tr>
                                <th>Sr No</th>
                                <th>EmpId</th>
                                <th>Name</th>
                                <th>Department Name</th>
                                <th>StartingDate</th>
                                <th>Attendance</th>
                                <th>AppRegister</th>
                                
            				</tr>
        				</thead>
        					<tbody>
        						<?php
try{
       include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
}
                                 $tsql="SELECT tblEmployee.EmployeeId,tblEmployee.EmpName,tblEmployee.DepartmentId,tblEmployee.StartingDate, tblDepartment.DepartmentId,tblDepartment.DepartmentName FROM tblEmployee,tblDepartment WHERE tblDepartment.DepartmentId = tblEmployee.DepartmentId";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt=1;
if ($getResults-> rowCount() > 0) {
foreach($results as $row){?>
    
    <tr><td><?php echo htmlentities($cnt);?></td><td><?php echo $row['EmployeeId'];?></td><td><?php echo $row['EmpName'];?></td>
        <td><?php echo $row['DepartmentName'];?></td><td><?php echo $row['StartingDate'];?></td><td><a href="viewemployeeattendance.php?empid=<?php echo $row['EmployeeId'];?>">View  <i class="fas fa-bell"></i></a></td><td><a href="addemployee.php?empid=<?php echo $row['EmployeeId'];?>">App Register <i class="fas fa-mobile-alt"></i></a></td>
    </tr>
    
<?php $cnt++; } } ?>
        					</tbody>
        			</table>
  			</form>
  		</div>
	</div>
	<script type="text/javascript">
		$(document).ready(function() {
    $('#example').DataTable();
} );
	</script>
</body>
</html>