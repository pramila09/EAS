<?php 
	define('DB_USERNAME','root');
	define('DB_PASSWORD','');
	define('DB_NAME','employees');
	define('DB_HOST','localhost');
	
	define('FIREBASE_API_KEY', 'AAAA61ioWm4:APA91bE2fWZDxeDgzInWmb8LWR7_BLQWrMwhtDJEwqi2my83LxsBaQJ7y36oXauCk2bnC4og02pw2xU5puro9OUeHDpLK7C6pEKZyvvqprbUMPsyKyj365I0iNykcvi93e3hIKMt2y6Z');
	?>