<?php 
//Connects your database
try{
   // include 'config.mssql.php';
  //$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);   
  
  $conn=new PDO("sqlsrv:Server=WINDOWS-UPVJIVE\PRAMILASQL,52704;Database=AMS2_project3x", "", "");
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(Exception $e)
    {
        die(print_r( $e->getMessage()));
    }

//This checks to see if there is a page number, that the number is not 0, and that the number is actually a number. If not, it will set it to page number to 1.
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }

//Now you can use this query to see how many rows you are dealing with
//Edit $result as your query
echo $result = "SELECT AttendanceLogId FROM tblAttendanceLog";
//$rows = mssql_num_rows($result);
$getResults=$conn->prepare($result);
$getResults->execute();
ini_set('memory_limit','-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
//$row=1;
echo $rows=$getResults-> rowCount();


//This is the number of results displayed per page 
$page_rows = 4; 

//This tells us the page number of our last page 
$last = ceil($rows/$page_rows); 

//Seeing if the current page we are on is the last
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; }

//This sets the range to display in our query 
$max = ($pagenum - 1) * $page_rows;?>

//This is your query again, just spiced up a bit
//mssql doesnt have that nice limit ability like mysql... so we use this to make it work...
//the way the table is designed is, "id" is the unique id, and "name" is just a list of names i have in there.
<?php echo $result2 = "select top $page_rows AttendanceLogId, EnrollDate, EnrollTime, EnrollNo from tblAttendanceLog where AttendanceLogId not in (select top $max AttendanceLogId from tblAttendanceLog order by AttendanceLogId asc) order by AttendanceLogId asc"; 

$getResults=$conn->prepare($result2);
$getResults->execute();
ini_set('memory_limit','-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt = 1;

if($getResults->rowCount() > 0)
                {
                foreach($results as $result)
                {
                  echo "<br>";
                   echo htmlentities($AttendanceLogId=$result['AttendanceLogId']);
                   echo "<br>";
                     echo htmlentities($EnrollNo=$result['EnrollNo']);
                     echo "<br>";
                     echo htmlentities($EnrollDate=$result['EnrollDate']);
                     echo "<br>";
                     echo htmlentities($EnrollTime=$result['EnrollTime']);
                     echo "<br>";
                     $cnt++;
                     }
                   }
//while($row=$getResults->fetchAll(PDO::FETCH_ASSOC)){
  //$Empid=array();
 //$Empid[] = $row['AttendanceLogId'];
   // $Empid[] = $row['EnrollDate'];
    //$Empid[] = $row['EnrollTime'];
    //$Empid[] = $row['EnrollNo'];

     //array_push($data, $Empid);
   
  // }
//This is where you show your results
//while($info = mssql_fetch_array( $result2 )) 
//{ 
//rint $info['name']; 
//echo "<br>";
//} 
/*
$data = array();
if ($results2) {
  foreach($results2 as $row) {
    $Empid = array();
    $Empid[] = $row['AttendanceLogId'];
    $Empid[] = $row['EnrollDate'];
    $Empid[] = $row['EnrollTime'];
    $Empid[] = $row['EnrollNo'];

     array_push($data, $Empid);
   }
   }else {
  die(json_encode($data));
}
*/


echo "<p>";

// This shows the page they are on, and the total number of pages
echo " --Page $pagenum of $last-- <p>";

// First we check if we are on page one. If we are then we don't need a link to the previous page or the first page so we do nothing. If we aren't then we generate links to the 

//first page, and to the previous page.
if ($pagenum == 1) { } 
else 
{
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=1'> <<-First</a> ";
echo " ";
$previous = $pagenum-1;
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$previous'> <-Previous</a> ";
} 

//just a spacer
echo " ---- ";

//This does the same as above, only checking if we are on the last page, and then generating the Next and Last links
if ($pagenum == $last) 
{
} 
else {
$next = $pagenum+1;
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$next'>Next -></a> ";
echo " ";
echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$last'>Last ->></a> ";
} 
?>