
<?php 
              try{
   include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
} 


 $request=$_REQUEST;

$col=array(
           
            0=>"EnrollDate",
            1=>"EnrollTime",
            2=>"EmployeeId",
            3=>"EmpName"
          );

$sql="SELECT count(distinct EnrollTime) as total FROM tblAttendanceLog,tblEmployee  WHERE tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo";
try{
  $getResults1=$conn->prepare($sql);
  $getResults1->execute();
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$result1=$getResults1->fetchAll(PDO::FETCH_BOTH);

//$result=$getResults1->fetchAll();
$total=$result1[0]["total"];
$totalFilter=intval($total);
echo $totalFilter;


$searchsql ="WHERE ";
if(!empty($_POST['search']['value'])){
    //$searchsql.=" (AttendanceLogId Like '".$request['search']['value']."%' ";
    //$searchsql.=" (EnrollDate Like '".$request['search']['value']."%' ";
    //$searchsql.=" OR EnrollTime Like '".$request['search']['value']."%' ";
    $searchsql.=" tblEmployee.EmpName Like '".$_POST['search']['value']."%' ";
}

  
  $datesearch="WHERE ";
  if($_POST["is_date_search"]=="yes")
  {
    $datesearch ='order_date between "'.$_POST["start_date"].'" and "'.$_POST["end_date"].'" and';
  }    
  
$last=$request['start'];
if(isset($_POST['order']))
{


$orderby=" ORDER BY ".$col[$_POST['order'][0]['column']]."   ".$_POST['order'][0]['dir']."  ";
}
$page_rows=$_POST['length'];

if(!empty($_POST['search']['value'])){

$tsql="SELECT tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime,tblEmployee.EmployeeId,tblEmployee.EmpName from tblAttendanceLog,tblEmployee where tblAttendanceLog.EnrollNo=tblEmployee.EnrollNo and $searchsql $orderby OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY ";
}

elseif ($_POST["is_date_search"]=="yes") {
 $tsql="SELECT tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime,tblEmployee.EmployeeId,tblEmployee.EmpName from tblAttendanceLog,tblEmployee where tblAttendanceLog.EnrollNo=tblEmployee.EnrollNo and $datesearch $orderby OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY ";
}
elseif(isset($_POST['order']))
   $tsql="SELECT tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime,tblEmployee.EmployeeId,tblEmployee.EmpName from tblAttendanceLog,tblEmployee where tblAttendanceLog.EnrollNo=tblEmployee.EnrollNo $orderby OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY ";
 else
  $tsql="SELECT tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime,tblEmployee.EmployeeId,tblEmployee.EmpName from tblAttendanceLog,tblEmployee where tblAttendanceLog.EnrollNo=tblEmployee.EnrollNo ";

//$query1 = '';

//if($_POST["length"] != -1)
//{
 //$query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
//}
//else
  //$query = "select  from tblAttendanceLog ";
try{
  $getResults=$conn->prepare($tsql);
  $getResults->execute();
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
      


$data = array();
if ($results) {
  foreach($results as $row) {
    $Empid = array();
    $Empid[] = $row[0];
    $Empid[] = $row[1];
    $Empid[] = $row[2];
    $Empid[] = $row[3];
   // $Empid[] = $row[4];
    
   // $Empid["name"] = "dinesh";

//$data[]=$Empid;
    //update our repsonse JSON data
    array_push($data, $Empid);
   
  }

  // echoing JSON response
  //echo json_encode($data);
}else {
  die(json_encode($data));
}

$json_data=array(
    "draw"=>intval($_POST['draw']),
    "recordsTotal"=>$total,
    "recordsFiltered"=>intval($totalFilter),
    "data"=>$data
);
echo json_encode($json_data);
?>

           