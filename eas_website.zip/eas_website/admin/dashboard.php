<?php 
include('includes/config.php');
?>
</html><!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php')?>
	<div class="header-style-dashboard">Dashboard</div>
	<div class="d-card1">
		<span class="headline1">Total Employees:</span><span class="stats-counter">
<?php
		try{
		       include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
		    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);}
			catch(Exception $e)
			{
			    die(print_r( $e->getMessage()));
			}
$tsql="SELECT * from tblEmployee";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$totalemp=1;
$totalemp = $getResults-> rowCount();?>
<span><?php echo htmlentities($totalemp);?></span></span>


	</div>
		<div class="d-card1"><span class="headline2">Total App Users:</span>
			<span class="stats-counter">
			<?php 
			$sql = "SELECT id from tblemployees";
			$query = $dbh -> prepare($sql);
			$query->execute();
			$results=$query->fetchAll(PDO::FETCH_OBJ);
			$empcount=$query->rowCount();
			?><span class="counter"><?php echo htmlentities($empcount);?></span></span>
		</div>
		<div class="d-card1"><span class="headline3">Total Departments:</span>
			<span class="stats-counter">
<?php

$tsql="SELECT * from tblDepartment";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$totaldept=1;
$totaldept= $getResults-> rowCount();?>
<span><?php echo htmlentities($totaldept);?></span></span>
	</div>
	<div class="datatable-cards">
		<div class="datatable-header-styles">App Registered Employees:</div>
  		<div class="datatable-container">
  			<form name="chngpwd" method="post">
  					<table id="example" class="display" style="width:100%">
        				<thead>
            				<tr>
				                <th>Sr no</th>
				                <th>EmpId</th>
                                <th>EmpName</th>
                                <th>Department</th>
                                <th>Email</th>
                                <th>Attendance</th>
            				</tr>
        				</thead>
        					<tbody>
        						<?php $sql = "SELECT * from tblemployees";
								$query = $dbh -> prepare($sql);
								$query->execute();
								$results=$query->fetchAll(PDO::FETCH_OBJ);
								$cnt=1;
								if($query->rowCount() > 0)
								{
								foreach($results as $result)
								{?>
										<tr>
                                            <td> <?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($result->Empid);?></td>
                                            <td><?php echo htmlentities($result->Fname);?></td>
                                            <td><?php echo htmlentities($result->department);?></td>
                                            <td><?php echo htmlentities($result->emailid);?></td>
                                            <td><a href="attendancetbl.php?aempid=<?php echo htmlentities($result->Empid);?>">View<i class="fas fa-bell"></i></a></td>
                                        </tr>
                                    <?php $cnt++;} }?>
        					</tbody>
        			</table>
  			</form>
  		</div>
	</div>

	<script type="text/javascript">
		$(document).ready(function() {
    $('#example').DataTable();
} );
	</script>
	
	

</body>
</html>