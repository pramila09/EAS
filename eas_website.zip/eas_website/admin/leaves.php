<?php
session_start();
if(!isset($_SESSION["username"]))
	die("not logged in");
$username=$_SESSION["username"];
$empid=$_SESSION["empid"];

include 'config.inc.php';



    //initial query
    $query = "SELECT fromdate, todate, leavetype, description, Status, empid FROM tbleaves where Empid = :Empid";

    $query_params = array(':Empid' => $empid);

    //execute query
    try {
        $stmt = $conn -> prepare($query);
        $result = $stmt -> execute($query_params);
    } catch (PDOException $ex) {        
        die(json_encode($response));
    }

    // Finally, we can retrieve all of the found rows into an array using fetchAll 
    $rows = $stmt -> fetchAll();
	$response = array();
    if ($rows) {
        
		
        foreach($rows as $row) {
            $Empid = array();
            $Empid["fromdate"] = $row["fromdate"];
            $Empid["todate"] = $row["todate"];
            $Empid["leavetype"] = $row["leavetype"];
            $Empid["description"] = $row["description"];
            $Empid["Status"] = $row["Status"];
            //update our repsonse JSON data
            array_push($response, $Empid);
        }

        // echoing JSON response
        echo json_encode($response);

    } else {
        die(json_encode($response));
    }



       ?>