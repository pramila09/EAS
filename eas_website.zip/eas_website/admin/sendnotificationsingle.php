
<?php
       try{
       	include 'config.inc.php';

       }
       catch(Exception $e)
      {
      	die(print_r($e->getMessage()));
      }
      $sql="SELECT * FROM tblemployees JOIN fcm_info ON tblemployees.Empid = fcm_info.empid";
					$getResult=$conn->prepare($sql);
					$getResult->execute();
					ini_set('memory_limit', '-1');
					$result=$getResult->fetchAll(PDO::FETCH_BOTH);
					$cnt2=1;
					?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>

	<?php include('includes/header.php')?>
	<div class="header-style-dashboard">Send Notification</div>
	<div class="d-card1">
		

<html>

<body>
	<form action="send_notification_single.php" method="post">
    <select name="fcm_token" class="dropdown-select" style = "margin-left: 3%;" autocomplete="off" required>
            		<option>---Select Employee---</option>
                  
					<?php
					if ($getResult-> rowCount() > 0) {
					foreach($result as $rows){?>
					
						<option value="<?php echo $rows['fcm_token'];?>"><?php echo $rows['Fname'];?></option>
					<?php $cnt2++; }}?>
					</select>
				
<table>
<tr>
<td> Title : </td><td><input type="text" name="title" required/>
</td>
</tr>

<tr>
<td> Message: </td><td><input type="text" name="message" required /></td>
</tr>

<td>
	<input type="submit" value="Submit"/>
	<?php
	if(isset($_GET["success"])){
		if($_GET["success"]==1)
			echo "Result: Notification was sent!";
		else
			echo "Result: Notification was not sent!";
	}
	?>
	
</td>

</tr>


</table>
</form>
</body>
</html>
</span>
</div>
</body>
</html>
