<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{
	header('location: index.php');
}
else{
if(isset($_POST['add']))
{
$leavetype=$_POST['leavetype'];
$description=$_POST['description'];  
$sql="INSERT INTO tbleavestypes(leavetype, description) VALUES(:leavetype,:description)";
$query = $dbh->prepare($sql);
$query->bindParam(':leavetype',$leavetype,PDO::PARAM_STR);
$query->bindParam(':description',$description,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Leave type added Successfully!";
}
else 
{
$error="Something went wrong. Please try again";
}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
</head>
<body>
	<?php include('includes/header.php')?>
	<div class="header-style">Add Leave Type</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="chngpwd" method="post">
  				<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?><br>
  				<input type="text" name="leavetype" id="leavetype" placeholder="leave type" autocomplete="off" required>
  				<textarea type="text" name="description" id="textarea" placeholder="description..." autocomplete="off" required></textarea>
  				<input class="button button2" type="submit" name="add" value="Add">
  			</form>
  		</div>
	</div>

</body>
</html>
<?php } ?>