<?php 
              try{
       include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
} 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin</title>
  <link rel="stylesheet" type="text/css" href="css/allstyle.css">
  <link rel="stylesheet" type="text/css" href="css/employeestyle.css">
  <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  

</head>
<body>
  <?php include('includes/header.php')?>
  <div class="datatable-header-style">Department Details</div>
  <div class="datatable-card">
      <div class="datatable-container">
        <form name="departments" method="post" action="adddepartment.php">
        <select name="department" id="department" class="dropdown-select" autocomplete="off" required>
              <option selected disabled>Choose Department..</option>
              <?php
              $sql="SELECT * FROM tblDepartment";
              $getResult=$conn->prepare($sql);
              $getResult->execute();
              ini_set('memory_limit', '-1');
              $result=$getResult->fetchAll(PDO::FETCH_BOTH);
              foreach($result as $Results){?>
              <option value="<?php echo $Results['DepartmentId']?>"><?php echo $Results['DepartmentName']?></option>
            <?php }?>
          <input class="button button2" id="submit" type="submit" name="submit" value="Submit">
            </select>
           
          </form>
          
        <form name="chngpwd" method="post">
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                                <th>Sr No</th>
                                <th>EmpId</th>
                                <th>EmpName</th>
                                
                    </tr>
                </thead>
                  <tbody>


<?php
if (isset($_POST['submit'])) {
  $dept = $_POST['department'];

$tsql="SELECT * FROM tblEmployee WHERE tblEmployee.DepartmentId = '$dept'";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt=1;
if ($getResults->rowCount() > 0) {
foreach($results as $row){?>
    <tr><td><?php echo htmlentities($cnt);?></td><td><?php echo $row['EmployeeId'];?></td><td><?php echo $row['EmpName'];?></td>
    </tr>
    
<?php $cnt++; }}}?>

                  </tbody>
              </table>
        </form>
      </div>
  </div>
  </script>
  <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>

</body>
</html>