<?php
session_start();
     include 'config.inc.php';
	 

	 // Check whether username or password is set from android	
     if(isset($_POST['username']) && isset($_POST['password']))
     {
		  // Innitialize Variable
		  $result='';
	   	  $username = $_POST['username'];
          $password = $_POST['password'];
		  
		  // Query database for row exist or not
          $sql = 'SELECT * FROM tblemployees WHERE  emailid= :username AND password = :password ';
          $stmt = $conn->prepare($sql);
          $stmt->bindParam(':username', $username, PDO::PARAM_STR);
          $stmt->bindParam(':password', $password, PDO::PARAM_STR);
		  
          $stmt->execute();
          if($stmt->rowCount())
          {
			 $result="true";	
			 $row = $stmt->fetch();
			 $_SESSION["empid"]= $row['Empid'];
			 $_SESSION["username"]=$username;
			  $_SESSION["emailid"]= $row['emailid'];
			 $_SESSION["Fname"]=$row['Fname'];
			  $_SESSION["department"]= $row['department'];
			
          }  
          else if(!$stmt->rowCount())
          {
			  	$result="false";
          }
		  
		  // send result back to android
   		  echo $result;
		  
  	}
	
?>


