<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{
	header('location: index.php');
}
else{
if(isset($_POST['add']))
{
$name=$_POST['eventname'];
$evtype=$_POST['eventtype'];
$startdate=$_POST['startdate']; 
$enddate=$_POST['enddate'];
$location=$_POST['location'];   
$status=1;
$sql="INSERT INTO events(evName,Category,StartDate,EndDate,Location,Status) VALUES(:name,:evtype,:startdate,:enddate,:location,:status)";
$query = $dbh->prepare($sql);
$query->bindParam(':name',$name,PDO::PARAM_STR);
$query->bindParam(':evtype',$evtype,PDO::PARAM_STR);
$query->bindParam(':startdate',$startdate,PDO::PARAM_STR);
$query->bindParam(':enddate',$enddate,PDO::PARAM_STR);
$query->bindParam(':location',$location,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="New Event Created Successfully";
}
else 
{
$error="Something went wrong. Please try again";
}

}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
</head>
<body>
	<?php include('includes/header.php');?>
	<div class="header-style">New Event..</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="chngpwd" method="post"><?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?><br> 

  				<input type="text" name="eventname" id="eventname" placeholder="Event name" autocomplete="off" required>
  				<input type="text" name="eventtype" id="eventtype" placeholder="Event type" autocomplete="off" required>
  				<input type="Date" name="startdate" id="startdate" placeholder="Start Date" autocomplete="off" required>
  				<input type="Date" name="enddate" id="enddate" placeholder="End Date" autocomplete="off" required>
  				<input type="text" name="location" id="location" placeholder="Location" autocomplete="off" required>
  				<input class="button button2" type="submit" name="add" value="Add">
  			</form>
  		</div>
	</div>

</body>
</html>
<?php } ?>