<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{
  header('location: index.php');
}
else{
if(isset($_POST['update']))
{
$did=intval($_GET['deptid']);    
$deptname=$_POST['departmentname'];
$deptshortname=$_POST['departmentshortname'];
$deptcode=$_POST['deptcode'];   
$sql="update tbldepartments set departmentName=:deptname,departmentCode=:deptcode,departmentShortName=:deptshortname where id=:did";
$query = $dbh->prepare($sql);
$query->bindParam(':deptname',$deptname,PDO::PARAM_STR);
$query->bindParam(':deptcode',$deptcode,PDO::PARAM_STR);
$query->bindParam(':deptshortname',$deptshortname,PDO::PARAM_STR);
$query->bindParam(':did',$did,PDO::PARAM_STR);
$query->execute();
$msg="Department updated Successfully!";
}?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
</head>
<body>
	<?php include('includes/header.php')?>
	<div class="header-style">Update Department Detail</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="chngpwd" method="post">
  				<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?><br>
                <?php 
                $did=intval($_GET['deptid']);
                $sql = "SELECT * from tbldepartments WHERE id=:did";
                $query = $dbh -> prepare($sql);
                $query->bindParam(':did',$did,PDO::PARAM_STR);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>   				

  				<input type="text" name="departmentname" id="departmentname" value="<?php echo htmlentities($result->departmentName);?>" autocomplete="off" required>
  				<input type="text" name="departmentshortname" id="departmentshortname" value="<?php echo htmlentities($result->departmentShortName);?>" autocomplete="off" required>
  				<input type="text" name="deptcode" id="deptcode" value="<?php echo htmlentities($result->departmentCode);?>" autocomplete="off" required><?php }} ?>
  				<input class="button button2" type="submit" name="update" value="Update">
  			</form>
  		</div>
	</div>
</body>
</html>
<?php } ?>