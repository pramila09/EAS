<?php

try{
      include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
}

/* Set the number of results to display on each page. */

$rowsPerPage = 10;

 

/* Order target data by ID and select only items

   (by row number) to display on a given page.

   The query asks for one "extra" row as an

   indicator that another page of data exists. */

echo $tsql = "WITH tblAttendanceLog AS

            (SELECT ROW_NUMBER() OVER(ORDER BY AttendanceLogId) AS

                  EnrollNo,

                  EnrollDate,

                 EnrollTime

       FROM tblAttendanceLog)

         SELECT * FROM tblAttendanceLog

         WHERE EnrollNo BETWEEN ? AND ? + 1";

$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);

 

/* Determine which row numbers to display. */

if(isset($_REQUEST['lowRowNum']) &&

   isset($_REQUEST['highRowNum']))

{

      $lowRowNum = $_REQUEST['lowRowNum'];

      $highRowNum = $_REQUEST['highRowNum'];

}

else

{

      $lowRowNum = 1;

      $highRowNum = $rowsPerPage;

}

 

/* Set query parameter values. */

$params = array($lowRowNum, $highRowNum);

 

/* Execute the query. */

$stmt = sqlsrv_query($conn, $tsql, $params);
/* Retrieve one row to see if there is any data. */

$row = sqlsrv_fetch_array($stmt);

if($row === false)

{

      echo "Error in fetching row.";

     die( print_r( sqlsrv_errors(), true));

}

elseif($row[0] == 0) /* Special case of no data returned. */

{

      echo "No data returned.";

}

else /* A row was retrieved! */

{

   /* Set the number of rows that have been retrieved. */

   $rowsRetrieved = 1;

 

   /*Display table header. */

   print("<table border='1px'>

                <tr>

                   <td>Enroll No</td>

                   <td>Enroll Date</td>

                   <td>Enroll Time</td>

                </tr>");

 

   /* Display the retrieved rows while we haven't

      displayed all of $rowsPerPage and there is

      another row to display. */

   do

   {

         print("<tr>

                    <td>$row[0]</td>

                    <td>$row[1]</td>

                    <td>$row[2]</td>

                    </tr>");

         $rowsRetrieved++;

     

   } while ($rowsRetrieved <= $rowsPerPage &

            $row = sqlsrv_fetch_array($stmt));

     

   /* Close table. */

   print("</table></br></br>");

 

   /*If there are previous results, display the

     Previous Page link.*/

   if($lowRowNum > 1)

   {

      $prev_page_high = $lowRowNum;

      $prev_page_low = $lowRowNum - $rowsPerPage;

      $prevPage = "?lowRowNum=$prev_page_low".

                  "&highRowNum=$prev_page_high";

      print("<a href=$prevPage>".

            "Previous Page</a>&nbsp;&nbsp;&nbsp;");

   }

 

   /* If there are more results, display the Next Page link.

      We know there are more results if the last call to

      sqlsrv_fetch_array returned a row (the "extra" row).

   */

   if($row != false)

   {       

      $next_page_low = $highRowNum;

      $next_page_high = $highRowNum + $rowsPerPage;

      $nextPage = "?lowRowNum=$next_page_low".

                  "&highRowNum=$next_page_high";

      print("<a href=$nextPage>Next Page</a>");

   }    

} 
/* Set the number of results to display on each page. */

$rowsPerPage = 10;

  

/* Define a query to get the number of rows on the server.

   This query doesn't actually retrieve rows, it just

   retrieves the number of rows that are available. */

$tsql = "SELECT COUNT(AttendanceLogId)

             FROM tblAttendanceLog";

 

/* Execute the query. */

$stmt = sqlsrv_query($conn, $tsql);

if($stmt === false)

{

     echo "Error in query execution.";

     die( print_r( sqlsrv_errors(), true));

}

 

/* Get the number of rows returned. */

$rowsReturned = sqlsrv_fetch_array($stmt);

if($rowsReturned === false)

{

     echo "Error in retrieving number of rows.";

     die( print_r( sqlsrv_errors(), true));

}

elseif($rowsReturned[0] == 0)

{

      echo "No rows returned.";

}

else

{    

      /* Display page links. */

      $numOfPages = ceil($rowsReturned[0]/$rowsPerPage);

      for($i = 1; $i<=$numOfPages; $i++)

      {

            $pageNum = "?pageNum=$i";

            print("<a href=$pageNum>$i</a>&nbsp;&nbsp;");

      }

      echo "</br></br>";

} 

 /* Order target data by ID and select only items

   (by row number) to display on a given page. */

$tsql = "WITH tblAttendanceLog AS

            (SELECT ROW_NUMBER() OVER(ORDER BY AttendanceLogId)

                         AS EnrollNo,

                            EnrollDate,    

                           EnrollTime

             FROM tblAttendanceLog)

          SELECT * FROM tblAttendanceLog

          WHERE EnrollNo BETWEEN ? AND ?";

 

/* Determine which row numbers to display. */

if(isset($_REQUEST['pageNum']))

{

      $highRowNum = $_REQUEST['pageNum'] * $rowsPerPage;

      $lowRowNum = $highRowNum - $rowsPerPage;

}

else

{

      $lowRowNum = 1;

      $highRowNum = $rowsPerPage;

}

 

/* Set query parameter values. */

$params = array($lowRowNum, $highRowNum);

 

/* Execute the query. */

$stmt2 = sqlsrv_query($conn, $tsql, $params);

if($stmt2 === false)

{

     echo "Error in query execution.";

     die( print_r( sqlsrv_errors(), true));

}

 

/* Print table header. */

print("<table border='1px'>

           <tr>

              <td>Enroll No</td>

              <td>Enroll Date</td>

              <td>Enroll Time</td>

           </tr>");

 

/* Display results. */

while($row = sqlsrv_fetch_array($stmt2) )

{

      print("<tr>

                 <td>$row[0]</td>

                 <td>$row[1]</td>

                 <td>$row[2]</td>

             </tr>");

}

 

/* Close table. */

print("</table>");