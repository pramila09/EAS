
<?php
/*
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['hlogin'])==0)
    {   
header('location:index.php');
}
else{ 
	$deptid=$_SESSION['deptid'];
	echo $deptid;
    ?>
    <?php
if(isset($_POST['signin']))
{
	$uname = $_POST['username'];
	$pass = $_POST['password'];
	$sql = "SELECT * FROM tblhod WHERE Email = :uname and Password = :pass";
	$query = $dbh -> prepare($sql);
	$query->bindParam(':uname', $uname, PDO::PARAM_STR);
	$query->bindParam(':pass', $pass, PDO::PARAM_STR);
	$query->execute();
	$result = $query -> fetchAll(PDO::FETCH_OBJ);
	
	if($query-> rowCount() > 0)
	{
		
		$_SESSION['hlogin'] = $uname;
		 $_SESSION["deptid"]= $row['Deptid'];
		echo "<script type = 'text/javascript'> document.location = 'dashboard.php'; </script>";
	}
	else
	{
		echo "<script>alert('invalid details!'); </script>";
	}
}
?>*/
session_start();

include 'config.inc.php';
	 

	 // Check whether username or password is set from android	
     if(isset($_POST['signin']))
     {
		  // Innitialize Variable
		  $result='';
	   	  $username = $_POST['username'];
          $password = $_POST['password'];
		  
		  // Query database for row exist or not
          $sql = 'SELECT * FROM tblhod WHERE  Email= :username AND password = :password ';
          $stmt = $conn->prepare($sql);
          $stmt->bindParam(':username', $username, PDO::PARAM_STR);
          $stmt->bindParam(':password', $password, PDO::PARAM_STR);
		  
          $stmt->execute();
          // $row = $stmt->fetch();
          if($stmt->rowCount())
          {
			 $result="true";

			 $row = $stmt->fetch();
			 $_SESSION["deptid"]= $row['Deptid'];
			 $_SESSION["username"]=$username;
			 echo "<script type = 'text/javascript'> document.location = 'dashboard.php'; </script>";
			 
			
          }  
          else if(!$stmt->rowCount())
          {
			  	$result="false";
			  	echo "<script>alert('invalid details!'); </script>";
          }
		  
		  // send result back to android
   		  echo $result;
		  
  	}
  	?>
<!DOCTYPE html>
<html>
<head>
	<title>Hod | Login</title>
	<link rel="stylesheet" type="text/css" href="../admin/css/loginstyle.css">
	<link rel="stylesheet" href="../admin/fontawesome/css/all.css">
</head>
<body>
	<div class="header-style">
		<span>Hod Login</span>
	</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="signin" method="post">
  				<input type="email" name="username" id="username" placeholder="email" autocomplete="off" required>
  				<input type="password" name="password" id="password" placeholder="password" autocomplete="off" required>
  				<input class="button button2" type="submit" name="signin" value="Login">
  			</form>
  		</div>
	</div>

</body>
</html>
