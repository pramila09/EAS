<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_SESSION['username'])) {
  echo "Your session is running " . $_SESSION['username'];
}

$id=intval($_GET['id']); 
//$id=$_SESSION["id"];
echo "id:".$id;

$empid=intval($_GET['empid']);
echo $empid;


   // unset($_SESSION["empid"]);
   // unset($_SESSION["id"]);
  
?>  