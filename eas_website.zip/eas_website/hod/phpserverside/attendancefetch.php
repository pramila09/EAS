<?php

       include 'config.mssql.php';

		$connectioninfo= array('UID' =>$mssql_user ,'PWD'=>$mssql_pass, 'Database'=>$mssql_db);
		$conn=sqlsrv_connect($mssql_server,$connectioninfo);

		$request=$_REQUEST;
		$col=array(
			0=>'AttendanceLogId',
			1=>'DeviceId',
			2=>'EnrollNo',
			3=>'EnrollDate',
			4=>'EnrollTime'
		);
		$tsql="SELECT * FROM tblAttendanceLog";
		$query=sqlsrv_query($conn,$tsql);
		//$getResults=$conn->prepare($tsql);
//$getResults->execute();
//ini_set('memory_limit', '-1');
//$results=$query->fetchAll(PDO::FETCH_BOTH);
$totalData=sqlsrv_num_rows($query);
//echo $totalData= $query-> rowCount();

$totalFilter=$totalData;
$data= array();
while($row=sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC)){
	$subdata=array();
	$subdata[]=$row[0];
	$subdata[]=$row[1];
	$subdata[]=$row[2];
	$subdata[]=$row[3];
	$subdata[]=$row[4];

	$data[]=$subdata;
	//echo "Just printing..";
}
$json_data=array(
	"draw"=>intval($request['draw']),
	"recordsTotal"=>intval($totalData),
	"recordFiltered"=>intval($totalFilter),
	"data"=>$data
);
echo json_encode($json_data);




		
		?>