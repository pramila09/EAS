<?php
try{

  $conn=new PDO("sqlsrv:Server=WINDOWS-UPVJIVE\PRAMILASQL,52704;Database=AMS2_project3x", "", "");
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
  die(print_r( $e->getMessage()));
}


$request=$_REQUEST;
$col=array(
            0=>"AttendanceLogId",
            1=>"EnrollDate",
            2=>"EnrollTime",
            3=>"EnrollNo"
      
        );
//echo $sql="SELECT top 10 * FROM tblAttendanceLog";
$sql="SELECT count(distinct AttendanceLogId) as total FROM tblAttendanceLog ";
//$tsql="SELECT top 10 AttendanceLogId, EnrollDate, EnrollTime, EnrollNo FROM tblAttendanceLog";

//echo "$year $nextyear";
//echo $tsql;
//die();
//$tsql_params = array(':Empid' => $empid);
//$draw=intval($request['draw']);
//$draw=isset($_GET['draw']);


try{
  $getResults1=$conn->prepare($sql);
  $getResults1->execute();
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$result1=$getResults1->fetchAll(PDO::FETCH_BOTH);

//$result=$getResults1->fetchAll();
$total=$result1[0]["total"];
$totalFilter=intval($total);
//$total = $results['total'];
//echo "total".$total;

/*
$sql="SELECT TOP 10 from tblAttendanceLog";
$getResults=$conn->prepare($sql);
$getResults->execute();
ini_set('memory_limit','-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$total=$getResults-> rowCount();
echo $total;
$totalFilter=intval($total);
*/
//$total=50;
//$totalFilter=50;

$searchsql ="WHERE ";
if(!empty($request['search']['value'])){
    //$searchsql.=" (AttendanceLogId Like '".$request['search']['value']."%' ";
    //$searchsql.=" (EnrollDate Like '".$request['search']['value']."%' ";
    //$searchsql.=" OR EnrollTime Like '".$request['search']['value']."%' ";
    $searchsql.=" EnrollNo Like '".$request['search']['value']."%' ";
}

/*$sql.=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  LIMIT ".
    $request['start']."  ,".$request['length']."  ";

$getResults=$conn->prepare($sql);*/
//$order="ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  LIMIT ";
//echo $order;


$last=$request['start'];


$orderby=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  ";




$page_rows=$request['length'];
/*
if($col[$request['column']]){
//echo $column;
$dir=$request['dir'];

if($column==0)
$orderby="AttendanceLogId";
else if($column==1)
$orderby="EnrollDate";
else if($column==2)
$orderby="EnrollTime";
else if($column==3)
$orderby="EnrollNo";

if($dir=="desc")
$direction="desc";
else
$direction="asc";
}*/
 //$last = ($draw - 1) * $page_rows;
 //echo "last row:".$last;
//echo "draw $draw";
//$tsql="SELECT TOP 20 tblAttendanceLog.AttendanceLogId,tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime,tblAttendanceLog.EnrollNo FROM tblAttendanceLog ORDER BY AttendanceLogId asc";
 //$tsql="SELECT AttendanceLogId, EnrollDate, EnrollTime, EnrollNo FROM tblAttendanceLog ORDER BY OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY";
if(!empty($request['search']['value'])){
     $tsql="SELECT AttendanceLogId, EnrollDate, EnrollTime, EnrollNo FROM tblAttendanceLog $searchsql $orderby
     OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY ";
    //echo $tsql;
    //die();
}
else
 $tsql="SELECT AttendanceLogId, EnrollDate, EnrollTime, EnrollNo FROM tblAttendanceLog $orderby OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY ";
//$tsql="SELECT top 10 AttendanceLogId, EnrollDate, EnrollTime, EnrollNo FROM tblAttendanceLog";

//echo "$year $nextyear";
//echo $tsql;
//die();
//$tsql_params = array(':Empid' => $empid);
//$draw=intval($request['draw']);
//$draw=isset($_GET['draw']);


try{
  $getResults=$conn->prepare($tsql);
  $getResults->execute();
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
//$cnt=1;

$data = array();
if ($results) {
  foreach($results as $row) {
    $Empid = array();
    $Empid[] = $row[0];
    $Empid[] = $row[1];
    $Empid[] = $row[2];
    $Empid[] = $row[3];
    
   // $Empid["name"] = "dinesh";

//$data[]=$Empid;
    //update our repsonse JSON data
    array_push($data, $Empid);
   
  }

  // echoing JSON response
  //echo json_encode($data);
}else {
  die(json_encode($data));
}
$json_data=array(
    "draw"=>intval($request['draw']),
    "recordsTotal"=>$total,
    "recordsFiltered"=>intval($totalFilter),
    "data"=>$data
);
echo json_encode($json_data);

?>

    
    

