<?php
try{
       include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		catch(Exception $e)
		{
		    die(print_r( $e->getMessage()));
		}
//$page_rows=isset($_POST["limit-records"]) ? $_POST["limit-records"]: 25;
		$page_rows=50;
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = isset($_GET['pagenum'])?$_GET['pagenum'] : 1; }
$max = ($pagenum - 1) * $page_rows;


		//$tsql="SELECT * FROM tblAttendanceLog ORDER By AttendanceLogId ASC OFFSET 10 ROWS FETCH NEXT 10 ROWS ONLY";
		//$result=sqlsrv_query($conn,$tsql);
	//	$data=$result->fetch_all(SQLSRV_FETCH_ASSOC);
$query="SELECT AttendanceLogId FROM tblAttendanceLog";
//echo $query;
//$rows=sqlsrv_num_rows($query);
$getResults=$conn->prepare($query);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$row=1;
//echo $row= $getResults-> rowCount();


$pagenum = isset($_GET['pagenum'])?$_GET['pagenum'] : 1;
$last=ceil($row/$page_rows);
$Previous=$pagenum - 1;
$Next=$pagenum +1;
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; }
else { $pagenum = isset($_GET['pagenum'])?$_GET['pagenum'] : 1; }
$max = ($pagenum - 1) * $page_rows;

//echo $tsql="SELECT * FROM (SELECT AttendanceLogId, EnrollDate, EnrollTime, Row_Number() over (order by AttendanceLogId) as RowNum FROM tblAttendanceLog ORDER By AttendanceLogId)T WHERE T.RowNum BETWEEN ((@pagenum-1)*@pagerow)+1 AND (@pagenum*@pagerow) ";
echo $tsql="SELECT * FROM tblAttendanceLog ORDER By AttendanceLogId ";//ASC OFFSET $max ROWS FETCH NEXT $page_rows ROWS ONLY";
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit','-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Demo Server Side Processing</title>
	<!--bootstrap-->
	 <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- datatable lib -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
</head>
<body>
	<br /><br />  
           <div class="container">  
                <h3 align="center">Datatables Jquery Plugin with Php MySql and Bootstrap</h3>  
                <br />  
               
<div class="row">
			<div class="col-md-10">
				<nav aria-label="Page navigation">
					<ul class="pagination">
				    <li>
				      <a href="index.php?pagenum=<?= $Previous; ?>" aria-label="Previous">
				        <span aria-hidden="true">&laquo; Previous</span>
				      </a>
				    </li>
				    <?php for($i = 1; $i<= $last; $i++) : ?>
				    	<li><a href="index.php?pagenum=<?= $i; ?>"><?= $i; ?></a></li>
				    <?php endfor; ?>
				    <li>
				      <a href="index.php?pagenum=<?= $Next; ?>" aria-label="Next">
				        <span aria-hidden="true">Next &raquo;</span>
				      </a>
				    </li>
				  </ul>
				</nav>
			</div>
			<div class="text-center" style="margin-top: 20px; " class="col-md-2">
				<form method="post" action="#">
						<select name="limit-records" id="limit-records">
							<option disabled="disabled" selected="selected">---Limit Records---</option>
							<?php foreach([10,100,500,1000,5000] as $limit): ?>
								<option <?php if( isset($_POST["limit-records"]) && $_POST["limit-records"] == $limit) echo "selected" ?> value="<?= $limit; ?>"><?= $limit; ?></option>
							<?php endforeach; ?>
						</select>
					</form>
				</div>
		</div>




                     <table id="employee_data" class="table table-striped table-bordered">  
                          <thead>  
                               <tr>  
                                    <td>Sr No</td>  
                                    <td>Enroll Date</td>  
                                    <td>Enroll Time</td>  
                                     
                               </tr>  
                          </thead>  
                          <tbody>
                          <?php  
                         if($getResults->rowCount()>0){
                         	foreach ($results as $result)
                         	 {?>
                         	 	<tr>
                         		<td><?php echo htmlentities($AttendanceLogId=$result['AttendanceLogId']);?></td>
                         		<td><?php echo htmlentities($EnrollDate=$result['EnrollDate']);?></td>

                         		<td><?php echo htmlentities($EnrollTime=$result['EnrollTime']);?></td>
                         		<?php echo '<br>';?>
                         <?php	}
                         }?>
                     </tr>
<?php  /*
                               echo '  
                               <tr>  
                                    <td>'.$row["AttendanceLogId"].'</td>  
                                  
                               </tr>  
                               ';  */?>
                           
                           </tbody>
                     </table>  



                </div>  

                <div style="position: fixed; bottom: 10px; right: 10px; color: green;">
        <strong>
            Learn Web Coding
        </strong>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$("#limit-records").change(function(){
			$('form').submit();
		})
	})
</script>
         
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 });  
 </script>  