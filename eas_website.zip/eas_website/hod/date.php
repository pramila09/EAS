 <?php

 $totaldays=15;
  $d1 = date_create(2014/12/13);
                                    $d2 = date_create(2014/12/15);
                                    $diff=date_diff($d1,$d2);

                                    $d = $diff->format("%a");
                                    $f = $totaldays - $d;
                                    echo $f;
                                    ?>