


<?php 
              try{
   include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
} 

session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['username'])==0)
    {   
header('location:index.php');
}

else{ 
  $deptid=$_SESSION['deptid'];


$request=$_REQUEST;
$cnt=1;
$col=array(
            
            0=>"EnrollDate",
            1=>"EnrollTime",
            2=>"EmployeeId",
            3=>"EmpName"
      
        );
//if (isset($_POST['submit'])) {
  //          $date = $_POST['enrolldate'];
            //$date='2014-03-01';


$date=$_GET['date'];
//echo $date;
//echo $date;
            $dates=explode("-",$date);
            $year=$dates[0];
//echo $year;
            $month=$dates[1];
           //echo $month;

            $day=$dates[2];
            //echo $day;
            $nextyr=$year+1;
            //echo $nextyr;



if($date=$_GET['date']){
//$sql="SELECT count(distinct EnrollTime) as total FROM tblAttendanceLog  WHERE tblAttendanceLog.EnrollDate < '$nextyr-01-01' AND tblAttendanceLog.EnrollDate >= '$year-01-01' AND tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo";
$sql="SELECT count(distinct tblAttendanceLog.AttendanceLogId) as total FROM tblAttendanceLog,tblEmployee WHERE tblAttendanceLog.EnrollDate < '$nextyr-01-01' AND tblAttendanceLog.EnrollDate >= '$year-01-01' AND tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo AND tblEmployee.DepartmentId=$deptid";
try{
  $getResults1=$conn->prepare($sql);
  $getResults1->execute();
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$result1=$getResults1->fetchAll(PDO::FETCH_BOTH);
if(empty($result1)){
//echo "test";
}
//print_r($result1);
//$result=$getResults1->fetchAll();
$total=$result1[0]["total"];
$totalFilter=$total;
//echo $totalFilter;

$searchsql ="WHERE ";
if(!empty($request['search']['value'])){
    //$searchsql.=" (AttendanceLogId Like '".$request['search']['value']."%' ";
    //$searchsql.=" (EnrollDate Like '".$request['search']['value']."%' ";
    //$searchsql.=" OR EnrollTime Like '".$request['search']['value']."%' ";
    $searchsql.=" EmpName Like '".$request['search']['value']."%' ";
}
$last=$request['start'];


$orderby=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  ";




$page_rows=$request['length'];

if(!empty($request['search']['value'])){


            //$date='2019-01';
            $tsql="SELECT tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime, tblEmployee.EmployeeId, tblEmployee.EmpName FROM tblEmployee,tblAttendanceLog $searchsql and tblAttendanceLog.EnrollDate < '$nextyr-01-01' AND tblAttendanceLog.EnrollDate >= '$year-01-01' AND tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo AND tblEmployee.DepartmentId=$deptid $orderby OFFSET $last ROWS FETCH NEXT $page_rows ROWS ONLY";
        }
        else
        	$tsql="SELECT tblAttendanceLog.EnrollDate,tblAttendanceLog.EnrollTime, tblEmployee.EmployeeId, tblEmployee.EmpName FROM tblEmployee,tblAttendanceLog WHERE tblAttendanceLog.EnrollDate < '$nextyr-01-01' AND tblAttendanceLog.EnrollDate >= '$year-01-01' AND tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo AND tblEmployee.DepartmentId=$deptid $orderby OFFSET $last  ROWS FETCH NEXT $page_rows ROWS ONLY";
      //  echo $tsql;


if(!empty($request['search']['value'])){
  $sql="SELECT count(distinct tblAttendanceLog.AttendanceLogId) as total FROM tblAttendanceLog,tblEmployee $searchsql and tblAttendanceLog.EnrollDate < '$nextyr-01-01' AND tblAttendanceLog.EnrollDate >= '$year-01-01' AND tblEmployee.EnrollNo = tblAttendanceLog.EnrollNo AND tblEmployee.DepartmentId=$deptid";
}
try{
  $getResults1=$conn->prepare($sql);
  $getResults1->execute();
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$result1=$getResults1->fetchAll(PDO::FETCH_BOTH);

//$result=$getResults1->fetchAll();
$totalFilter=$result1[0]["total"];


        try{
  $getResults=$conn->prepare($tsql);
  $getResults->execute();
  //echo $getResults;
}
catch (PDOException $ex) {        
  //die(json_encode($data));
}
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
//$cnt=1;

$data = array();
if ($results) {
  foreach($results as $row) {
    $Empid = array();
    $Empid[] = $row[0];
    $Empid[] = $row[1];
    $Empid[] = $row[2];
    $Empid[] = $row[3];
    
    
   // $Empid["name"] = "dinesh";

//$data[]=$Empid;
    //update our repsonse JSON data
    array_push($data, $Empid);
   
  }

  // echoing JSON response
  //echo json_encode($data);
}else {
  die(json_encode($data));
}
$json_data=array(
    "draw"=>intval($request['draw']),
    "recordsTotal"=>$total,
    "recordsFiltered"=>intval($totalFilter),
    "data"=>$data
);
echo json_encode($json_data);
}}
?>