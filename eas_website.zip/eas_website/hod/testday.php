<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['username'])==0)
    {   
header('location:index.php');
}
 
  $deptid=$_SESSION['deptid'];
  //echo $deptid;
//$empid=$_SESSION["empid"];
//echo "empid:".$empid;
$id=intval($_GET['id']); 
//$id=$_SESSION["id"];
//echo "id:".$id;

$empid=intval($_GET['empid']);
//echo $empid;

if(isset($_POST['update']))
{
//$leveid=intval($_GET['levid']);  
//echo $leveid;
//$deptid=$_S  
$status=$_POST['status'];
                    if ($status == 1) {
                     //   $sql1 = "SELECT * from tbleaves WHERE id=:leveid";
/*
                       $sql = "SELECT * from tblhod where Deptid=$deptid.";
                       echo $sql;
                       $query = $dbh -> prepare($sql);
                       $query->execute();
                       $results=$query->fetchAll(PDO::FETCH_OBJ);
                       $cnt=1;
                       if($query->rowCount() > 0)
                       {
                          foreach($results as $result)
                       {
                  
                                             $dept = htmlentities($result->Department);
                                            $cnt++;} }*/
                               
                                             

                        $sql1 = "SELECT tbleaves.fromdate,tbleaves.todate,tblemployees.RemainingDays from tbleaves JOIN tblemployees ON tbleaves.empid=$empid and tbleaves.id=$id AND tbleaves.department=tblemployees.department";
                      //  echo $sql1;
                        $query1 = $dbh -> prepare($sql1);
                      // $query1->bindParam(':empid',$empid,PDO::PARAM_STR);
                       // $query1->bindParam(':leveid',$leveid,PDO::PARAM_STR);
                        $query1->execute();
                        $results1=$query1->fetchAll(PDO::FETCH_OBJ);
                        $cnt=1;
                        if($query1->rowCount() > 0)
                        {
                        foreach($results1 as $result1)
                        {                 

                                    $totaldays = htmlentities($result1->RemainingDays);
                                   // echo "totaldays".$totaldays;
                                   
                                  //  $d1 = date_create($result1->fromdate);
                                    //$d2 = date_create($result1->todate);
                                    $d1 = date_create($result1->fromdate);
                                    $d2 = date_create($result1->todate);
                                    $diff=date_diff($d1,$d2);
                                    $d = $diff->format("%a");
                                    $f = $totaldays - $d;
                                    //echo $f;
                                  
                                    $sql3 = "update tblemployees set RemainingDays = $f where empid=$empid";
                                   // echo $sql3;
                                    $query3 = $dbh->prepare($sql3);
                                    $query3->bindParam(':f',$f,PDO::PARAM_STR);
                                    $query3->bindParam(':empid',$empid,PDO::PARAM_STR);
                                    $query3->bindParam(':leveid',$leveid,PDO::PARAM_STR);
                                    $query3->execute();
?>

                                   <?php }}}?><?php
$sql="update tbleaves set Status=$status where empid=$empid and id=$id";
//echo $sql;

$query = $dbh->prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':empid',$empid,PDO::PARAM_STR);
$query->bindParam(':leveid',$leveid,PDO::PARAM_STR);
$query->execute();

echo "<script type = 'text/javascript'> document.location = 'allleaves.php'; </script>";
}?>
</html><!DOCTYPE html>
<html>
<head>
	<title>HOD</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="css/employeestyle.css">
</head><body>
	<?php include('includes/header.php')?>
	<div class="datatable-header-style">HOD Action</div>

	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="post">
<?php 
$id=intval($_GET['id']); 
//$id=$_SESSION["id"];
//echo "id:".$id;

$empid=intval($_GET['empid']);
//echo $empid;

$sql = "SELECT * from tbleaves where empid=$empid and id=$id";
//echo $sql;
$query = $dbh -> prepare($sql);
$query->bindParam(':empid',$empid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>                    
  				<select name="status" id="status" class="dropdown-select" autocomplete="off" required>
              <option selected disabled>Choose Action..</option>
              <option value="1">Approved</option>
              <option value="2">Not Approved</option>
          </select>

          <?php $cnt++; 
        }}?>
          <input class="button button2" id="update" type="submit" name="update" value="Update">
                    
  			</form>
  		</div>
  	</div>

</body>
</html>