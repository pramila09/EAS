<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<nav>
		<ul>
			<li class="active"><a href="dashboard.php">dashboard</a></li>

			<li><a href="manageemployee.php">employee</a>
				
			</li>

			<li><a href="allleaves.php">leaves detail</a>
			</li>
			<li><a href="">view attendance</a>
			<ul>
				<li><a href="viewattendanceyearly.php">view yearly attendance</a></li>
				<li><a href="viewattendancemonthly.php">view monthly attendance</a></li>
				<li><a href="viewattendance.php">view daily attendance</a></li>
			</ul>
			</li>
	<li><a href="changepassword.php">change password</a></li>
			<li><a href="logout.php">logout</a></li>

		</ul>
	</nav>

</body>
</html>