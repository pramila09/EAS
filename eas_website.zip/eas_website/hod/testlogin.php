<?php
   session_start();
     
	//if(!isset($_SESSION["username"]))
	//die("not logged in");
if(isset($_SESSION["username"])){
$uname=$_SESSION["username"];
$deptidid=$_SESSION["deptid"];

}
include 'config.inc.php';
	 

	 // Check whether username or password is set from android	
     if(isset($_POST['username']) && isset($_POST['password']))
     {
		  // Innitialize Variable
		  $result='';
	   	  $username = $_POST['username'];
          $password = $_POST['password'];
		  
		  // Query database for row exist or not
          $sql = 'SELECT * FROM tblhod WHERE  Email= :username AND password = :password ';
          $stmt = $conn->prepare($sql);
          $stmt->bindParam(':username', $username, PDO::PARAM_STR);
          $stmt->bindParam(':password', $password, PDO::PARAM_STR);
		  
          $stmt->execute();
          if($stmt->rowCount())
          {
			 $result="true";	
			 $row = $stmt->fetch();
			 $_SESSION["deptid"]= $row['Deptid'];
			 $_SESSION["username"]=$username;
			 
			
          }  
          else if(!$stmt->rowCount())
          {
			  	$result="false";
          }
		  
		  // send result back to android
   		  echo $result;
		  
  	}
?>
<!DOCTYPE html><html>
<head>
	<title>Admin | Login</title>

</head>
<body>
	<div class="header-style">
		<span>Admin Login</span>
	</div>

	<div class="login-card">
  		<div class="login-container">
  			<form name="signin" method="post">
  				<input type="text" name="username" id="username" placeholder="username" autocomplete="off" required>
  				<input type="password" name="password" id="password" placeholder="password" autocomplete="off" required>
  				<input class="button button2" type="submit" name="signin" value="Login">
  			</form>
  		</div>
	</div>

</body>
</html>