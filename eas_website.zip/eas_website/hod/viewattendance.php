<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HOD</title>
    <!--bootstrap-->
     <link rel="stylesheet" type="text/css" href="css/allstyle.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">

</head>
<body>
    <?php include('includes/header.php')?>
    <div class="datatable-header-style">Daily Attendance Report</div>
    <div class="datatable-card">
        <div class="datatable-container">
            <form name="departments" method="post" action="viewattendance.php">
            <label for="enrolldate">Choose Date:</label>
            <input type = "date" id="enrolldate" name="enrolldate" autocomplete="off">
          <input class="button button2" id="submit" type="submit" name="submit" value="Go">
          </form>
   
        <table id="example" class="display" width="100%">
            <thead>
            <tr>
                
                <th>Enroll Date</th>
                <th>Enroll Time</th>
                <th>Employee Id</th>
                <th>Employee Name</th>
             
            </tr>
            </thead>
            <tfoot>
            <tr>
              
                <th>EnrollDate</th>
                <th>EnrollTime</th>
                  <th>EmployeeId</th>
                <th>EmpName</th>
              
                
            </tr>
            </tfoot>

<?php 
            if (isset($_POST['submit'])) {
            $date = $_POST['enrolldate'];
          //  echo $date;
}
?>




        </table>

        <!--create modal dialog for display detail info for edit on button cell click-->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
                <div id="content-data"></div>
            </div>
        </div>
    </div>


    <script>
        $(document).ready(function(){
            var dataTable=$('#example').DataTable({
                "processing": true,
                "serverSide":true,

                "ajax": 
                "viewattendanceindex.php?date=<?php echo $date; ?>",
                 
        /*  "createdRow": function (row, data, index) {
              var info = dataTable.page.info();
              $('td', row).eq(0).html(index + 1 + info.page * info.length);
          },  */  
          
             error: function () {  // error handling
                  $(".employee-grid-error").html("");
                  $("#employee-grid").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
                  $("#employee-grid_processing").css("display", "none");
              }
            

                

            });
        });
    </script>
 
    <script>
        $(document).on('click','#getEdit',function(e){
            e.preventDefault();
            var per_id=$(this).data('id');
            //alert(per_id);
            $('#content-data').html('');
            $.ajax({
                url:'editdata.php',
                type:'POST',
                data:'id='+per_id,
                dataType:'html'
            }).done(function(data){
                $('#content-data').html('');
                $('#content-data').html(data);
            }).fial(function(){
                $('#content-data').html('<p>Error</p>');
            });
            



 </script>  
</body>
</html>