<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['hlogin'])==0)
    {   
header('location:index.php');
$deptid=$_SESSION['deptid'];
	echo $deptid;
}

else{ 
echo "not logged in";
}
    ?>