<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['username'])==0)
    {   
header('location:index.php');
}

else{ 
	$deptid=$_SESSION['deptid'];
//	echo $deptid;
//	echo $_SESSION['username'];
    ?>

    


</html><!DOCTYPE html>
<html>
<head>
	<title>HOD</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php')?>
                <?php 
                $email = $_SESSION['username'];
                $e = $email;
                
                $sql = "SELECT * FROM tblhod";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>
                  
                                            <?php $dept = htmlentities($result->Deptid);?>
                                           
                                            	  
                                    <?php $cnt++;} }?>
	<div class="d-card1" style="margin-top: 30px;">
		<span class="headline1">Total Employees:</span><span class="stats-counter">
<?php
		try{
		    include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
		    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);}
			catch(Exception $e)
			{
			    die(print_r( $e->getMessage()));
			}
				$tsql="SELECT * FROM tblEmployee where DepartmentId = $deptid";
				//echo $tsql;
				$getResults=$conn->prepare($tsql);
				$getResults->execute();
				ini_set('memory_limit', '-1');
				$results=$getResults->fetchAll(PDO::FETCH_BOTH);
				$totalemp=1;
				$totalemp = $getResults-> rowCount();?>
				<span><?php echo htmlentities($totalemp);?></span></span>

	</div>
		
	
  			</form>
  		</div>
	</div>

</body>
</html>
<?php }?>