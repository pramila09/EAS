<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(strlen($_SESSION['username'])==0)
    {   
header('location:index.php');

}

else{ 
    $deptid=$_SESSION["deptid"];
   // echo $deptid;
    //echo $_SESSION['username'];
    ?>
<!DOCTYPE html>
<html>
<head>
	<title>HOD</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>
	<?php include('includes/header.php')?>
                <?php $sql = "SELECT * from tblhod";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>
                  
                                            <?php $dept = htmlentities($result->Deptid);?>
                                        
                                    <?php $cnt++;} }?>

  <div class="datatable-header-style">Employees</div>
	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="post">
  					<table id="example" class="display" name="example" style="width:100%">
        				<thead>
            				<tr>
                                <th>Sr No</th>
                                <th>EmpId</th>
                                <th>Name</th>
                               
                                <th>StartingDate</th>
                                <th>Attendance</th>
                                <th>Leave Report</th>
                                
            				</tr>
        				</thead>
        					<tbody>
        						<?php

                    
                      
try{
   include 'config.mssql.php';
$conn=new PDO("sqlsrv:Server=$mssql_server;Database=$mssql_db", $mssql_user, $mssql_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
    die(print_r( $e->getMessage()));
}

$tsql="SELECT * FROM tblEmployee where DepartmentId = $deptid";
//echo $tsql;
$getResults=$conn->prepare($tsql);
$getResults->execute();
ini_set('memory_limit', '-1');
$results=$getResults->fetchAll(PDO::FETCH_BOTH);
$cnt=1;
if ($getResults-> rowCount() > 0) {
foreach($results as $row){?>
    
    <tr><td><?php echo htmlentities($cnt);?></td><td><?php echo $row['EmployeeId'];?></td><td><?php echo $row['EmpName'];?>
        </td><td><?php echo $row['StartingDate'];?>
        <td><a href="attendance.php?aempid=<?php echo $row['EmployeeId'];?>">View<i class="fas fa-bell"></i></a></td><td><a href="leavehistory.php?aempid=<?php echo $row['EmployeeId'];?>">details<i class="fas fa-history"></i></a></td>
    </tr>
    <a href="attendanceindex.php?aempid=<?php echo $row['EmployeeId'];?>";
<?php $cnt++; } } ?>
        					</tbody>
        			</table>
  			</form>
  		</div>
	</div>
	<script type="text/javascript">
		$(document).ready(function() {
    $('#example').DataTable();
} );
	</script>
</body>
</html
<?php } ?>