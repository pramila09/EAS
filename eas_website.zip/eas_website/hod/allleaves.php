<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['username'])==0)
    {   
header('location:index.php');
}
else{
//echo $_SESSION['username'];
    $deptid=$_SESSION["deptid"];
    //echo $deptid;
    //echo $_SESSION['username'];
if(isset($_POST['update']))
{ 
$status=$_POST['status'];   
$sql="update tblleaves set Status=:status";
$query = $dbh->prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':did',$did,PDO::PARAM_STR);
$query->execute();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>HOD</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
</head>
<body>

   
                <?php $sql = "SELECT * from tblhod where Deptid=$deptid.";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>
                  
                                            <?php $dept = htmlentities($result->Department);?>
                                        
                                    <?php $cnt++;} }?>

                                     <?php 
                                            $sql = "SELECT * from tblemployees where Empid=$empid";
                                            $query = $dbh -> prepare($sql);
                                            $query->execute();
                                            $results=$query->fetchAll(PDO::FETCH_OBJ);
                                            $cnt=1;
                                            if($query->rowCount() > 0)
                                            {
                                               foreach($results as $result)
                                            {?>
                  
                                            <?php  $remainingdays = htmlentities($result->RemainingDays);
                                        $cnt++;}}?>



	<?php include('includes/header.php')?>

	<div class="datatable-header-style">All Leave History</div>

	<div class="datatable-card">
  		<div class="datatable-container">
  			<form name="chngpwd" method="post"><?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
  					<table id="example" class="display" style="width:100%">
        				<thead>
            				<tr>
				                <th>Sr no</th>
				                <th>EmpName</th>
                                <th>Email</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Remaining Days</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Remarks</th>
                               
            				    </tr>
        				</thead>
                <tbody>
                    <?php $sql = "SELECT tblemployees.empid,tblemployees.RemainingDays,tbleaves.id,tbleaves.empName,tbleaves.email,tbleaves.fromdate,tbleaves.todate,tbleaves.leavetype,tbleaves.Status FROM tbleaves JOIN tblemployees ON tbleaves.department = '$dept'AND tbleaves.department=tblemployees.department;";
                  //  echo $sql;
                $query = $dbh -> prepare($sql);
                $query->execute();

                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                { 
                foreach($results as $result)
                { 
                    $empid=htmlentities($result->empid);
                    $_SESSION["empid"]=$empid;
                   // echo "empid".$empid;?>
                    <?php $remainingdays=htmlentities($result->RemainingDays);
                    $_SESSION["remainingdays"]=$remainingdays;?>
                    <?php $id=htmlentities($result->id);
                    $_SESSION["id"]=$id;
//echo "id".$id;


                    ?>
                    <tr>  

                   
                                            <td> <?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($result->empName);?></td>
                                            <td><?php echo htmlentities($result->email)?></td>
                                            <td><?php echo htmlentities($result->fromdate);?></td>
                                            <td> <?php echo htmlentities($result->todate);?></td>
                                     

                                        <td> <?php echo $remainingdays;?></td>

                                            <td> <?php echo htmlentities($result->leavetype);?></td>
                                            <td><?php $stats=$result->Status;
                                                if($stats==1){?>
                                                <span style="color: green">Approved</span>
                                                 <?php } if($stats==2)  { ?>
                                                <span style="color: red">Not Approved</span>
                                                <?php } if($stats==0)  { ?>
                                                 <span style="color: blue">waiting for approval</span>
                                                 <?php } ?></td>
                                            
                                            <td><a href="testday.php?id=<?php echo htmlentities($result->id);?> & empid=<?php echo htmlentities($result->empid);?>">Take Action</a></td>
                                           
                                           
                                              

                                        </tr>
                                           
                                        </tr>

   

                            <?php $cnt++;} }?>  


                  </tbody>
        			</table>
  			</form>
  		</div>
	</div>
    <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>

</body>
</html>
<?php } ?>