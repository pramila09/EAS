<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['username'])==0)
    {   
header('location:index.php');
}
else{
?>
</html><!DOCTYPE html>
<html>
<head>
	<title>HOD</title>
	<link rel="stylesheet" type="text/css" href="css/allstyle.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">

	
</head>
<body>
	<?php include('includes/header.php');?>

	<div class="datatable-header-style">Leave Report</div>
	<div class="datatable-card">
	<div class="datatable-container">
  			<form name="chngpwd" method="post"><?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
  					<table id="example" class="display" style="width:100%">
        				<thead>
            				<tr>
				                <th>Sr no</th>
				                <th>EmpName</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Type</th>
                                <th>Description</th>
            				    </tr>
        				</thead>
                <tbody>
                    <?php 
                    $eid=intval($_GET['aempid']);
                    $sql = "SELECT * FROM tbleaves,tblemployees where tbleaves.empid = $eid AND tblemployees.Empid = $eid";
                $query = $dbh -> prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {?>
                    <tr>
                                            <td> <?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($result->Fname);?></td>
                                            
                                            <td><?php echo htmlentities($result->fromdate);?></td>
                                            <td> <?php echo htmlentities($result->todate);?></td>
                                            
                                            <td> <?php echo htmlentities($result->leavetype);?></td>

                                            <td> <?php echo htmlentities($result->description);?></td>
                                           
                                            
                                        </tr>
                                           
                                        </tr>
                                    <?php $cnt++;} }?>
                  </tbody>
        			</table>
  			</form>
  		</div>
	</div>
    <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>


</body>
</html>
<?php } ?>